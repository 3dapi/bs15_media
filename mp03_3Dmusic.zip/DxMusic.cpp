// Implementation of the DxMusic class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


// From http://www.GameDev.net

MUSIC_TIME DmUtil_GetTimeOffset(IDirectMusicPerformance8* pPerform, IDirectMusicSegment8* pSegment)
 {

	IDirectMusicSegmentState*	pSegState = NULL;
	MUSIC_TIME mtNow;           // From GetTime
	MUSIC_TIME mtStartTime;     // From GetStartTime
	MUSIC_TIME mtStartPoint;    // From GetStartPoint
	MUSIC_TIME mtLoopStart;     // From GetLoopPoints
	MUSIC_TIME mtLoopEnd;       // From GetLoopPoints
	MUSIC_TIME mtLength;        // From GetLength
	DWORD dwLoopRepeats;        // From GetRepeats
	
//	pSegment->GetTime		(&mtNow);
//	pSegment->GetStartTime	(&mtStartTime);
//	pSegment->GetStartPoint	(&mtStartPoint);
//	pSegment->GetLoopPoints	(&mtLoopStart, &mtLoopEnd);
//	pSegment->GetLength		(&mtLength);
//	pSegment->GetRepeats	(&dwLoopRepeats);

	pPerform ->GetTime(NULL, &mtNow);
	pPerform ->GetSegmentState(&pSegState, mtNow);
	pSegState->GetStartPoint(&mtStartPoint);
	pSegState->GetStartTime(&mtStartTime);
	pSegment ->GetLoopPoints(&mtLoopStart, &mtLoopEnd);
	pSegment ->GetRepeats(&dwLoopRepeats);
	
//	if(thisAudio->audioType == WAV)
//		pSegment->SetLength(mtNow);

	pSegment->GetLength(&mtLength);
	
	// Convert mtNow from absolute time to an offset
	// from when the segment started playing
	LONGLONG llOffset = mtNow - (mtStartTime - mtStartPoint);
	
	// If loopEnd is non zero, set lLoopEnd to loopEnd,
	// otherwise use the segment length
	LONGLONG llLoopEnd = mtLoopEnd ? mtLoopEnd : mtLength;
	LONGLONG llLoopStart = mtLoopStart;
	
	if((dwLoopRepeats != 0) && (llLoopStart < llLoopEnd) && (llLoopEnd > mtStartPoint))
	{
		if((dwLoopRepeats != DMUS_SEG_REPEAT_INFINITE) && (llOffset > (llLoopStart + (llLoopEnd - llLoopStart) * (signed)dwLoopRepeats)))
		{
			llOffset -= (llLoopEnd - llLoopStart) * dwLoopRepeats;
		}
		else if( llOffset > llLoopStart )
		{
			llOffset = llLoopStart + (llOffset - llLoopStart) % (llLoopEnd - llLoopStart);
		}
	}
	
	llOffset = min( llOffset, LONG_MAX );	// LONG_MAX is defined in Limits.h.
	
	return MUSIC_TIME(llOffset);
}



DxMusic::DxMusic()
: pDLoader(0)
, pOdioPth(0)
, pPerform(0)
, pSegment(0)
, mtPause(0)
{
}


DxMusic::DxMusic(	IDirectMusicLoader8*		_pDLoader
				,	IDirectMusicAudioPath*		_pOdioPth
				,	IDirectMusicPerformance8*	_pPerform
				,	IDirectMusicSegment8*		_pSegment)
: pDLoader(_pDLoader)
, pOdioPth(_pOdioPth)
, pPerform(_pPerform)
, pSegment(_pSegment)
, mtPause(0)
{
}


DxMusic::~DxMusic()
{
	Stop();
	
	if(pSegment)
	{
		pSegment->Release();
		pSegment = NULL;
	}

	if(pOdioPth)
	{
		pOdioPth->Release();
		pOdioPth = NULL;
	}

	if(pPerform)
	{
		pPerform->Stop(NULL, NULL, 0, 0);
		pPerform->Release();
		pPerform = NULL;
	}
}


void DxMusic::Play()
{
	pSegment->SetStartPoint(mtPause);
	pPerform->PlaySegmentEx(pSegment, NULL, NULL, pOdioPth? DMUS_SEGF_DEFAULT : 0, 0, NULL, NULL, pOdioPth);
}

void DxMusic::Stop()
{
	if(S_OK == pPerform->IsPlaying(pSegment, NULL))
		pPerform->StopEx(pSegment, 0, 0);
	
	mtPause	= 0;
}

void DxMusic::Reset()
{
	mtPause	= 0;
}


void DxMusic::SetRepeat(DWORD dRepeat)
{
	pSegment->SetRepeats(dRepeat);
}


void DxMusic::Pause()
{
	if(S_OK == pPerform->IsPlaying(pSegment, NULL))
	{
		mtPause = DmUtil_GetTimeOffset(pPerform, pSegment);
		pPerform->StopEx(pSegment, 0, 0);
	}
}






DxSnd3D::DxSnd3D()
{
	pMusic		= NULL;
	pD3Buff		= NULL;
	pD3Lstn		= NULL;
}


DxSnd3D::~DxSnd3D()
{
	if(pMusic)
	{
		delete pMusic;
		pMusic = NULL;
	}
}


void DxSnd3D::Play()
{
	pMusic->Play();
}

void DxSnd3D::Stop()
{
	pMusic->Stop();
}

void DxSnd3D::Reset()
{
	pMusic->Reset();
}


void DxSnd3D::SetRepeat(DWORD dRepeat)
{
	pMusic->SetRepeat(dRepeat);
}


void DxSnd3D::Pause()
{
	pMusic->Pause();
}


INT DxSnd3D::Create(DxMusic* pMusic)
{
	HRESULT hr;
	
	this->pMusic	= pMusic;
	
	// 3D buffer
	if (FAILED(hr = pMusic->pOdioPth->GetObjectInPath(0, DMUS_PATH_BUFFER, 0, GUID_NULL, 0, IID_IDirectSound3DBuffer, (void**)&pD3Buff)))
		return -1;
	
	// listener
	if (FAILED(hr = pMusic->pOdioPth->GetObjectInPath(0, DMUS_PATH_PRIMARY_BUFFER, 0, GUID_NULL, 0, IID_IDirectSound3DListener, (void**)&pD3Lstn)))
		return -1;

	
	// 3D buffer parameters
	memset( &DsBuff, 0, sizeof DsBuff);
	memset( &DsLstn, 0, sizeof DsLstn);

	DsBuff.dwSize = sizeof DsBuff;
	DsBuff.dwMode = DS3DMODE_NORMAL;
	DsBuff.flMinDistance = 0;
	DsBuff.flMaxDistance = 50.f;
	pD3Buff->SetAllParameters(&DsBuff, DS3D_IMMEDIATE);


	DsLstn.dwSize = sizeof DsLstn;
	DsLstn.flDopplerFactor = 0;
	DsLstn.flRolloffFactor = 0.1f;
	pD3Lstn->SetAllParameters(&DsLstn, DS3D_IMMEDIATE);

	return 0;
}


void DxSnd3D::SetPosSource(float x, float y, float z)
{
	if(pD3Buff)
		pD3Buff->SetPosition(x, y, z, DS3D_IMMEDIATE);
}


void DxSnd3D::SetPosListener(float x, float y, float z)
{
	if(pD3Lstn)
	{
		pD3Lstn->SetPosition(x,y,z, DS3D_IMMEDIATE);
	}
}







CDxMusicManager::CDxMusicManager()
{
	m_pLoader	= NULL;
	m_pPerform	= NULL;
}

CDxMusicManager::~CDxMusicManager()
{
	if(m_pPerform)
	{
		m_pPerform->Stop(NULL, NULL, 0, 0);
		m_pPerform->CloseDown();
		m_pPerform->Release();
		m_pPerform = NULL;
	}

	if(m_pLoader)
	{
		m_pLoader->Release();
		m_pLoader = NULL;
	}

	CoUninitialize();
}


INT CDxMusicManager::Initialize(HWND hWnd)
{
	HRESULT hr;

	m_hWnd	 = hWnd;

	char pathStr[MAX_PATH];       // path for audio file
	WCHAR wcharStr[MAX_PATH];
	
	if (FAILED(hr=CoInitialize(NULL)))
		return -1;
	
	
	// create the loader object
	if (FAILED(CoCreateInstance(CLSID_DirectMusicLoader, NULL, CLSCTX_INPROC, IID_IDirectMusicLoader8, (void**)&m_pLoader)))
		return -1;
	

	// retrieve the current directory
	GetCurrentDirectory(MAX_PATH, pathStr);
	MultiByteToWideChar(CP_ACP, 0, pathStr, -1, wcharStr, MAX_PATH);

	m_pLoader->SetSearchDirectory(GUID_DirectMusicAllTypes, wcharStr, FALSE);



	// Create IDirectMusicPerformance8
	if (FAILED(CoCreateInstance(CLSID_DirectMusicPerformance, NULL, CLSCTX_INPROC, IID_IDirectMusicPerformance8, (void**)&m_pPerform)))
		return -1;
	

	if (FAILED(m_pPerform->InitAudio(NULL, NULL, m_hWnd, DMUS_APATH_DYNAMIC_STEREO, 128, DMUS_AUDIOF_ALL, NULL)))
		return -1;


	return 0;
}



INT CDxMusicManager::Create(DxSnd3D** pSnd3D, char* sFile)
{
	DxMusic*	pMusic = NULL;

	if(FAILED(this->Create(&pMusic, sFile, DMUS_APATH_DYNAMIC_3D, TRUE)))
		return -1;

	pMusic->SetRepeat();
	(*pSnd3D)			= new DxSnd3D;
		
	if(FAILED( (*pSnd3D)->Create(pMusic) ))
		return -1;
	
	return 0;
}


// Load the Segment From File
INT CDxMusicManager::Create(DxMusic** pMusic, char* sFile, DWORD dwDefaultPathType, BOOL bUseAudio)
{
	HRESULT	hr;
	
	IDirectMusicSegment8*		pSegment	= NULL;								// the Segment
	IDirectMusicPerformance8*	pPerform	= NULL;								// the Performance
	IDirectMusicAudioPath*		pOdioPth	= NULL;								// Audio path

	if (FAILED(CoCreateInstance(CLSID_DirectMusicPerformance, NULL, CLSCTX_INPROC, IID_IDirectMusicPerformance8, (void**)&pPerform)))
		return -1;
	
	if(FAILED(pPerform->InitAudio(NULL, NULL, m_hWnd, dwDefaultPathType, 128, DMUS_AUDIOF_ALL, NULL)))
		return -1;

	if(bUseAudio)
	{
		if (FAILED(hr = pPerform->CreateStandardAudioPath(dwDefaultPathType, 128, TRUE, &pOdioPth)))
			return -1;

	}


	WCHAR	wsFile[MAX_PATH];
	MultiByteToWideChar(CP_ACP, 0, sFile, -1, wsFile, MAX_PATH);				// convert sFile to unicode string
	
	// Load from File
	if (FAILED(hr = m_pLoader->LoadObjectFromFile(CLSID_DirectMusicSegment,	IID_IDirectMusicSegment8,	wsFile,	(void**)&pSegment)))
	{
		MessageBox(m_hWnd, "Load Music File Failed", "Err", MB_ICONEXCLAMATION);
		return -1;
	}
	
	pSegment->Download(pPerform);												// download the segment's instruments to the synthesizer
	
	(*pMusic) = new DxMusic( m_pLoader, pOdioPth, pPerform, pSegment);
	
	return 0;
}




// Load the Segment From Resource
INT CDxMusicManager::Create(DxMusic** pMusic, INT nResourceID, char* sResourceType, DWORD dwDefaultPathType, BOOL bUseAudio)
{
	HRESULT	hr;
	
	IDirectMusicSegment8*		pSegment	= NULL;								// the Segment
	IDirectMusicPerformance8*	pPerform	= NULL;								// the Performance
	IDirectMusicAudioPath*		pOdioPth	= NULL;								// Audio path

	if (FAILED(CoCreateInstance(CLSID_DirectMusicPerformance, NULL, CLSCTX_INPROC, IID_IDirectMusicPerformance8, (void**)&pPerform)))
		return -1;
	
	if(FAILED(pPerform->InitAudio(NULL, NULL, m_hWnd, dwDefaultPathType, 128, DMUS_AUDIOF_ALL, NULL)))
		return -1;

	if(bUseAudio)
	{
		if (FAILED(hr = pPerform->CreateStandardAudioPath(dwDefaultPathType, 128, TRUE, &pOdioPth)))
			return -1;

	}

	HINSTANCE				hInst		= GetModuleHandle(NULL);
	HRSRC					hres		= NULL;
	void*					pMem		= NULL;
	DWORD					dwSize		= 0;
	DMUS_OBJECTDESC			objdesc;
	
	
	// Find the resource 
	if( !(hres = FindResource( hInst,MAKEINTRESOURCE(nResourceID), sResourceType )))
		return -1;
	
	
	// Load the resource
	if( !(pMem = (void*)LoadResource(hInst, hres)) ) 
		return -1;
	
	
	// Memory Size of the resource
	dwSize = SizeofResource(hInst,hres);
	
	// Set up object description 
	ZeroMemory(&objdesc,sizeof(DMUS_OBJECTDESC));
	objdesc.dwSize = sizeof(DMUS_OBJECTDESC);
	objdesc.dwValidData = DMUS_OBJ_MEMORY | DMUS_OBJ_CLASS;
	objdesc.guidClass = CLSID_DirectMusicSegment;
	objdesc.llMemLength =(LONGLONG)dwSize;
	objdesc.pbMemData = (BYTE*)pMem;
	
	if(FAILED( hr = m_pLoader->GetObject( &objdesc, IID_IDirectMusicSegment8, (void**)&pSegment )))
		return -1;
	

	pSegment->Download(pPerform);
	
	(*pMusic)	= new DxMusic( m_pLoader, pOdioPth, pPerform, pSegment);
	
	return 0;
}