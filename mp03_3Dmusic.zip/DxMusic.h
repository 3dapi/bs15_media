// Interface for the CDxMusic class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _DXMUSIC_H_
#define _DXMUSIC_H_


struct DxMusic
{
	IDirectMusicLoader8*		pDLoader;		// Music Loader
	IDirectMusicAudioPath*		pOdioPth;		// Music Audiopath
	IDirectMusicPerformance8*	pPerform;		// Music Performance
	IDirectMusicSegment8*		pSegment;		// Music Segment

	MUSIC_TIME					mtPause;
	
	DxMusic();
	DxMusic(	IDirectMusicLoader8*		_pDLoader
			,	IDirectMusicAudioPath*		_pOdioPth
			,	IDirectMusicPerformance8*	_pPerform
			,	IDirectMusicSegment8*		_pSegment);

	~DxMusic();

	void	Play();
	void	Stop();
	void	Reset();
	void	Pause();

	void	SetRepeat(DWORD dRepeat= DMUS_SEG_REPEAT_INFINITE);
};


struct DxSnd3D
{
	IDirectSound3DBuffer*		pD3Buff;		// 3d buffer
	IDirectSound3DListener*		pD3Lstn;		// 3d listener
	
	DS3DBUFFER					DsBuff;			// 3d buffer properties
	DS3DLISTENER				DsLstn;			// 3d listener properties

	DxMusic*					pMusic;

	DxSnd3D();
	~DxSnd3D();

	void	Play();
	void	Stop();
	void	Reset();
	void	Pause();

	INT		Create(DxMusic*	pMusic);

	void	SetRepeat(DWORD dRepeat= DMUS_SEG_REPEAT_INFINITE);
	void	SetPosSource(float x, float y, float z);
	void	SetPosListener(float x, float y, float z);
};


class CDxMusicManager
{
public:
	HWND						m_hWnd;
	IDirectMusicLoader8*		m_pLoader;			// Music Loader
	IDirectMusicPerformance8*	m_pPerform;			// For Test

public:
	CDxMusicManager();
	virtual ~CDxMusicManager();

	INT		Initialize(HWND hWnd);
	void	Destroy();
	INT		Create(DxSnd3D** pSnd3D, char* sFile);								// From File

	INT		Create(DxMusic** pMusic
					, char* sFile
					, DWORD dwDefaultPathType=DMUS_APATH_SHARED_STEREOPLUSREVERB
					, BOOL	bUseAudio=FALSE);									// From File
	
	INT		Create(DxMusic** pMusic
					, INT nResourceID
					, char* sResourceType
					, DWORD dwDefaultPathType=DMUS_APATH_SHARED_STEREOPLUSREVERB
					, BOOL	bUseAudio=FALSE);									// From Resource
};



#endif