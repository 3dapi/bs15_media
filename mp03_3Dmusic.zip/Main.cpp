// Implementation of the CMain class.
//
//////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pSnd3D1		= NULL;
	m_pSnd3D2		= NULL;

	m_pMusicManager = NULL;
	
	
}


INT CMain::Init()
{
	// Music �Ŵ����� �����.
	m_pMusicManager = new CDxMusicManager;

	if(FAILED(m_pMusicManager->Initialize(m_hWnd)))
		return -1;
	

	// Music Manager�� ���ؼ� 3D ���带 �����.
	if(FAILED(m_pMusicManager->Create(&m_pSnd3D1, "Sound/CANYON.MID")))
		return -1;

	if(FAILED(m_pMusicManager->Create(&m_pSnd3D2, "Sound/ringout.wav")))
		return -1;

	m_pSnd3D1->Play();
	m_pSnd3D2->Play();
	
	return 0;
}

void CMain::Destroy()
{
	SAFE_DELETE(	m_pSnd3D1		);

	SAFE_DELETE(	m_pMusicManager	);
}




INT CMain::Restore()
{
	return 0;
}


void CMain::Invalidate()
{
}


INT CMain::FrameMove()
{
	static float fAngle=0;

	fAngle +=.4f;

	float xPos = 15.f * cosf(fAngle* 3.14159265f/180.f);
	float yPos = 15.f * sinf(fAngle* 3.14159265f/180.f);
	

	m_pSnd3D1->SetPosSource(xPos, 0, 0);
	m_pSnd3D2->SetPosListener(yPos, 0, 0);


	char sMsg[128];
	sprintf(sMsg, "%f %f", xPos, yPos);
	SetWindowText(m_hWnd, sMsg);
	
	return 0;
}


INT CMain::Render()
{
	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xFF006699, 1.0f, 0 );
	
	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;
	
	// EndScene
	m_pd3dDevice->EndScene();
	
	return 0;
}


LRESULT CMain::MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch( msg )
	{
	case WM_PAINT:
		{
			break;
		}
	}
	
	return CApplication::MsgProc( hWnd, msg, wParam, lParam );
}