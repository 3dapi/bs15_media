// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAIN_H_
#define _MAIN_H_

class CMain : public CApplication
{
public:
	DxSnd3D*			m_pSnd3D1;
	DxSnd3D*			m_pSnd3D2;
	
	CDxMusicManager*	m_pMusicManager;

public:
	CMain();

	virtual INT		Init();
	virtual void	Destroy();

	virtual INT		Restore();
	virtual void	Invalidate();

	virtual INT		FrameMove();
	virtual INT		Render();

	virtual LRESULT MsgProc(HWND, UINT, WPARAM, LPARAM);
};

#endif