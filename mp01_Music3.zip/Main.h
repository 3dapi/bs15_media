// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAIN_H_
#define _MAIN_H_


#include <dmusicc.h>			// DirectMusic includes
#include <dmusici.h>

class CMain : public CApplication
{
public:
	CMcInput*			m_pInput;

	
	IDirectMusicLoader8*		m_pLoader ;										// Loader
	IDirectMusicSegment8*		m_pSegment;										// Segment
	IDirectMusicPerformance8*	m_pPerform;										// Performance
	IDirectMusicAudioPath*		m_pAudioPath;									// Audio Path

	LONG						m_dVolume;										// ����: �ִ� 0 �ּ� -9600

public:
	CMain();

	virtual INT		Init();
	virtual void	Destroy();

	virtual INT		Restore();
	virtual void	Invalidate();

	virtual INT		FrameMove();
	virtual INT		Render();

	virtual LRESULT MsgProc(HWND, UINT, WPARAM, LPARAM);
};

#endif