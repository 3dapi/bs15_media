// Interface for the CMcDShow  class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCDSHOW_H_
#define _MCDSHOW_H_


#define WM_DSHOW_EVENT		(WM_USER+800)

class CMcDShow
{
public:
	class IDShowBase
	{
	public:
		IDShowBase(){};
		virtual ~IDShowBase(){};

		virtual INT		Create(LPDIRECT3DDEVICE9 pDev, char* sFile)=0;
		virtual void	Destroy()=0;

		virtual INT		ProcessEvent()=0;
		virtual INT		Stop()=0;
		virtual INT		Reset()=0;

		virtual LPDIRECT3DTEXTURE9	GetTexture()=0;
		virtual INT					GetVidWidth() =0;
		virtual INT					GetVidHeight()=0;
	};



protected:
	LPDIRECT3DDEVICE9	m_pDev;
	IDShowBase*			m_pVid;

public:
	CMcDShow();
	virtual ~CMcDShow();

	INT		Create(LPDIRECT3DDEVICE9 pDev, char* sFile);
	void	Destroy();

	INT		FrameMove();
	
	LPDIRECT3DTEXTURE9 GetTexture();

	INT		GetVidWidth();
	INT		GetVidHeight();
};

#endif