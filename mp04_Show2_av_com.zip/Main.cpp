// Implementation of the CMain class.
//
//////////////////////////////////////////////////////////////////////////////

#define _WIN32_WINNT	0x400

// Need DShowStrmBase.lib....
// You must be copy below codes..

// Begin------------------------------------------------------------------------
	#ifdef _DEBUG
	#pragma comment(lib, "DShowStrmbase_.lib")
	#else
	#pragma comment(lib, "DShowStrmbase.lib")
	#endif
// End--------------------------------------------------------------------------


#include "_StdAfx.h"


CMain::CMain()
{
	m_pDShow	= NULL;
}


INT CMain::Init()
{
	if(!m_pDShow)
	{
		m_pDShow = new CMcDShow;

		if(FAILED(m_pDShow->Create(m_pd3dDevice, "Media/skiing.avi")))
			return -1;
	}

	
	return 0;
}

void CMain::Destroy()
{
	SAFE_DELETE(	m_pDShow	);
}




INT CMain::Restore()
{
	return 0;
}


void CMain::Invalidate()
{
}


INT CMain::FrameMove()
{
	if(	m_pDShow	)
		m_pDShow->FrameMove();

	return 0;
}


INT CMain::Render()
{
	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xFF006699, 1.0f, 0 );
	
	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;
	
	RECT rtScn={0};

	LPDIRECT3DTEXTURE9 pTx = m_pDShow->GetTexture();

	rtScn.right = m_pDShow->GetVidWidth();
	rtScn.bottom= m_pDShow->GetVidHeight();

	D3DXVECTOR3	vcScl;
	vcScl.x = FLOAT(m_dScnX)/FLOAT(rtScn.right) * 0.5f;
	vcScl.y = vcScl.x;
	vcScl.z =  0.f;

	D3DXVECTOR3	vcPos(10.f, 20.f, 0);

	D3DXMATRIX	mtWld;
	static D3DXMATRIX	mtI(1,0,0,0,    0,1,0,0,    0,0,1,0,    0,0,0,1);
	
	D3DXMatrixIdentity(&mtWld);
	
	D3DXMatrixScaling(&mtWld, vcScl.x, vcScl.y, vcScl.z);
	mtWld._41 = vcPos.x;
	mtWld._42 = vcPos.y;
	mtWld._43 = vcPos.z;


	m_pd3dSprite->SetTransform(&mtWld);
	m_pd3dSprite->Begin(D3DXSPRITE_ALPHABLEND);
	m_pd3dSprite->Draw(pTx, &rtScn, &vcScl, &vcPos, D3DXCOLOR(1,1,1,1));
	m_pd3dSprite->End();

	m_pd3dSprite->SetTransform(&mtI);
	

	
	// EndScene
	m_pd3dDevice->EndScene();
	
	return 0;
}


LRESULT CMain::MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch( msg )
	{
		case WM_DSHOW_EVENT:
		{
//			CMcDShow::IDShowBase* pDShow = (CMcDShow::IDShowBase*)lParam;
//			pDShow->ProcessEvent();
			break;
		}


		case WM_PAINT:
		{
			break;
		}
	}
	
	return CApplication::MsgProc( hWnd, msg, wParam, lParam );
}