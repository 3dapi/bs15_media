// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pSoundManager		= NULL;
	m_pBounceSound		= NULL;
}


INT CMain::Init()
{
	m_pSoundManager = new CSoundManager();
	
	if( FAILED( m_pSoundManager->Initialize( m_hWnd, DSSCL_PRIORITY ) ) )
		return -1;
	
	if( FAILED( m_pSoundManager->SetPrimaryBufferFormat( 2, 22050, 16 ) ) )
		return -1;
	
	m_pSoundManager->Create( &m_pBounceSound, "Sound/3dsound.WAV", 0, GUID_NULL, 1 );

	return 0;
}

void CMain::Destroy()
{
	if(m_pBounceSound)
		m_pBounceSound->Stop();
	
	SAFE_DELETE( m_pBounceSound );
	SAFE_DELETE( m_pSoundManager );
}




INT CMain::Restore()
{
	return 0;
}


void CMain::Invalidate()
{
}


INT CMain::FrameMove()
{
	if(::GetAsyncKeyState(VK_F11) & 0x8000)
	{
//		DSUtil_PlaySound(m_pBounceSound);
		DSUtil_PlaySoundLooping(m_pBounceSound);
	}
	
	return 0;
}


INT CMain::Render()
{
	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xFF006699, 1.0f, 0 );

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	// EndScene
	m_pd3dDevice->EndScene();

	TCHAR	sMsg[128];
	sprintf(sMsg, "Sound Test Press F11 Key         FPS: %4.1f", m_fFps);
	SetWindowText(m_hWnd, sMsg);

	return 0;
}


LRESULT CMain::MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch( msg )
	{
		case WM_PAINT:
		{
			break;
		}
	}
	
	return CApplication::MsgProc( hWnd, msg, wParam, lParam );
}