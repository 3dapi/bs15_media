#define WIN32_LEAN_AND_MEAN

#pragma comment(lib, "winmm.lib")

#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }

#include <windows.h>

#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

#include "resource.h"

#include "ILpSmd.h"

HINSTANCE	m_hInst	= NULL;
HWND		m_hWnd	= NULL;
HACCEL		m_hAccel = NULL;

TCHAR		m_sCls[MAX_PATH]="Wave Test";

ILpSmd*		m_pSnd1 = NULL;


LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);


int APIENTRY WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nCmdShow)
{
	m_hInst = hInst;

	WNDCLASS wc;

	wc.style			= CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc		= (WNDPROC)WndProc;
	wc.cbClsExtra		= 0;
	wc.cbWndExtra		= 0;
	wc.hInstance		= m_hInst;
	wc.hIcon			= NULL;
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wc.lpszMenuName		= (LPCSTR)IDC_WAVETST;
	wc.lpszClassName	= m_sCls;
	
	if(0== RegisterClass(&wc))
		return -1;
	
	m_hWnd = CreateWindow(m_sCls
						, m_sCls
						, WS_OVERLAPPEDWINDOW
						, 0
						, 0
						, 800
						, 600
						, NULL
						, NULL
						, m_hInst
						, NULL);
	
	if(!m_hWnd)
		return -1;

	ShowWindow(m_hWnd, nCmdShow);
	UpdateWindow(m_hWnd);


	if( FAILED( LpSmd_Create("CE Sound File", &m_pSnd1, "Sound/tsound2.wav")))
		return -1;

//	m_pSnd1->SetRepeat(0xFFFFFFFF);

	m_hAccel = LoadAccelerators(m_hInst, (LPCTSTR)IDC_WAVETST);

	MSG	msg={0};
	
	while(WM_QUIT != msg.message)
	{
		GetMessage(&msg, NULL, 0, 0);

		if( msg.hwnd)
			TranslateAccelerator(msg.hwnd, m_hAccel, &msg);
		
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}


	SAFE_DELETE(	m_pSnd1		);

	
	return msg.wParam;
}



LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	INT wmId    = LOWORD(wParam); 
	INT wmEvent = HIWORD(wParam); 

	switch (message) 
	{
		case WM_KEYDOWN:
		{
			switch (wmId)
			{
				case VK_ESCAPE:
					SendMessage(hWnd, WM_DESTROY, 0, 0);
					break;

				case 'R':
					m_pSnd1->Reset();
					break;

				case 'P':
					m_pSnd1->Play();
					break;

				case 'S':
					m_pSnd1->Stop();
					break;
			}

			return 0;
		}


		case WM_DESTROY:
		{
			PostQuitMessage(0);
			break;
		}

		case WM_PAINT:
		{
			PAINTSTRUCT paint={0};
			HDC hdc = BeginPaint(hWnd, &paint);

			char smsg[] = "Try to press R, P or S key";

			TextOut(hdc, 10, 50, smsg, strlen(smsg));

			EndPaint(hWnd, &paint);
			return 0;
		}
			
	}


	return DefWindowProc(hWnd, message, wParam, lParam);
}

