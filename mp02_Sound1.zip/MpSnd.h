// Interface for the CMpSnd class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MpSnd_H_
#define _MpSnd_H_


class CMpSnd : public CLpSmdBase
{
protected:
	char*			m_pData;
	long			m_iData;
	WAVEFORMATEX	m_WavFMT;
	
	HWAVEOUT		m_WavOut;
	WAVEHDR			m_WavHDR;

	LONG			m_dVol;			// Volume
	DWORD			m_dRpt;			// Repeat
	DWORD			m_dStat;		// State 0: stop, 1: Play 2: Pause

public:
    CMpSnd();
    virtual ~CMpSnd();

public:
	virtual INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0);
	virtual void	Destroy();

	virtual INT		Query(char* sCmd, void* pData);


	virtual DWORD	GetType();
	virtual void	Play();
	virtual void	Stop();
	virtual void	Reset();
	virtual void	Pause();
	virtual void	SetVolume(LONG dVol);
	virtual LONG	GetVolume();
	virtual void	SetRepeat(DWORD dRepeat= 0xFFFFFFFF/*INFINITE*/);
	virtual DWORD	GetStatus();

	static void CALLBACK WaveOutProc(HWAVEOUT hWavOut, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2);

public:
	void	SetStatus(DWORD dSt);
	DWORD	GetRepeat();
};


#endif

