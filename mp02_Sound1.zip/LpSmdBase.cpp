// Implementation of the CLpSmdBase class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILpSmd.h"
#include "LpSmdBase.h"


CLpSmdBase::CLpSmdBase()
{
}

CLpSmdBase::~CLpSmdBase()
{
	CLpSmdBase::Destroy();
}


INT CLpSmdBase::Create(void* p1, void* p2, void* p3, void* p4)
{
//	printf("CLpSmdBase Create\n");
	return 0;
}

void CLpSmdBase::Destroy()
{
//	printf("CLpSmdBase Destroy\n");
}

INT	CLpSmdBase::FrameMove()
{
//	printf("CLpSmdBase FrameMove\n");
	return 0;
}

void CLpSmdBase::Render()
{
//	printf("CLpSmdBase Render\n");
}


INT CLpSmdBase::Query(char* sCmd, void* pData)
{
//	printf("CLpSmdBase Query:%s\n", sCmd);
	return 0;
}


DWORD  CLpSmdBase::GetType()
{
//	printf("CLpSmdBase GetType\n");
	return 0;
}

void  CLpSmdBase::Play()
{
//	printf("CLpSmdBase Play\n");
}

void  CLpSmdBase::Stop()
{
//	printf("CLpSmdBase Stop\n");
}


void  CLpSmdBase::Reset()
{
//	printf("CLpSmdBase Reset\n");
}


void  CLpSmdBase::Pause()
{
//	printf("CLpSmdBase Pause\n");
}


void  CLpSmdBase::SetVolume(LONG dVol)
{
//	printf("CLpSmdBase SetVolume\n");
}


LONG  CLpSmdBase::GetVolume()
{
//	printf("CLpSmdBase GetVolume\n");
	return -1;
}


void  CLpSmdBase::SetRepeat(DWORD dRepeat)
{
//	printf("CLpSmdBase SetRepeat\n");
}


DWORD  CLpSmdBase::GetStatus()
{
//	printf("CLpSmdBase GetStatus\n");
	return 0xFFFFFFFF;
}



void*  CLpSmdBase::GetTexture()
{
//	printf("CLpSmdBase GetTexture\n");
	return 0;
}


INT  CLpSmdBase::GetVideoW()
{
//	printf("CLpSmdBase GetVideoW\n");
	return -1;
}


INT  CLpSmdBase::GetVideoH()
{
//	printf("CLpSmdBase GetVideoH\n");
	return -1;
}


