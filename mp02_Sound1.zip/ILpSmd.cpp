// Implementation of the ILpSmd class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <mmsystem.h>

#include <stdio.h>


#include "ILpSmd.h"
#include "LpSmdBase.h"

#include "MpUtil.h"
#include "MpSnd.h"



WAVEOUTCAPS g_LpWaveOutCaps_a7d89cb0_1704_46e1_9d1a_635272e74b0b={0,};


INT LpSmd_DeviceInit()
{
	int WaveOutDeviceCount;

	WaveOutDeviceCount = waveOutGetNumDevs();

	if(WaveOutDeviceCount > 0)
	{
		if(MMSYSERR_NOERROR != waveOutGetDevCaps(0, &g_LpWaveOutCaps_a7d89cb0_1704_46e1_9d1a_635272e74b0b, sizeof(g_LpWaveOutCaps_a7d89cb0_1704_46e1_9d1a_635272e74b0b)))
			return -1;
	}
	
	return 0;
}


void	LpSmd_DeviceClose()
{
}



INT LpSmd_Create(char* sCmd
				, ILpSmd** pData
				, void* p1				// Wave File Name
				, void* p2
				, void* p3
				, void* p4
				, void* p5
				, void* p6
				, void* p7
				, void* p8
				)
{
	(*pData) = NULL;

	if(0==_stricmp("CE Sound File", sCmd))
	{
		// p1: HWND
		// p2: File Name
		// p3: 

		CMpSnd* pObj	= NULL;

		pObj = new CMpSnd;

		if(FAILED(pObj->Create(p1, p2, p3, p4)))
		{
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		return 0;
	}

	return -1;
}



