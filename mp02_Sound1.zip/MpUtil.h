// Interface for the MpUtilities.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MpUtil_H_
#define _MpUtil_H_


#define MEDIA_PLAY(p)				{	if(p){	(p)->Play() ;		}	}
#define MEDIA_STOP(p)				{	if(p){	(p)->Stop() ;		}	}
#define MEDIA_REST(p)				{	if(p){	(p)->Reset();		}	}
#define MEDIA_PAUSE(p)				{	if(p){	(p)->Pause();		}	}
#define MEDIA_REPEAT_INFINITE(p)	{	if(p){	(p)->SetRepeat();	}	}



#define MEDIA_MAX_VOLUME				10000L
#define MEDIA_MUSIC_MAX_VOLUME			9600L

#define MEDIA_STATE_STOP				0X00000000L
#define MEDIA_STATE_PLAY				0X00000001L
#define MEDIA_STATE_PAUSE				0X00000002L
#define MEDIA_STATE_RESET				0X00000004L



enum ELnMedia
{
	LNMDAFMT_WAV_		= 0x0008,	// 0000 0000 1000	: Wave
	LNMDAFMT_WAV_M		= 0x0009,	// 0000 0000 1001	: Wave		Mono and Stero
	LNMDAFMT_WAV_S		= 0x000C,	// 0000 0000 1100	: 3d		Sound

	LNMDAFMT_MSC_		= 0x0080,	// 0000 1000 0000	: Music
	LNMDAFMT_MW_M		= 0x0081,	// 0000 1000 0001	: Music		Wave
	LNMDAFMT_MW_S		= 0x0084,	// 0000 1000 0100	: Music		Wave 3D

	LNMDAFMT_MSC_M		= 0x0090,	// 0000 1001 0000	: Music		Mono and Stero
	LNMDAFMT_MSC_S		= 0x00C0,	// 0000 1100 0000	: Music		3D
	
	LNMDAFMT_SHW		= 0x0800,	// 1000 0000 0000	: DShow
	LNMDAFMT_SHW_M		= 0x0900,	// 1001 0000 0000	: DShow		Mp3
	LNMDAFMT_SHW_A		= 0x0A00,	// 1010 0000 0000	: DShow		AVI

	LPMDAFMT_WAV_		= 0xF008,	// 0000 0000 1000	: PDA Wave
	LPMDAFMT_WAV_M		= 0xF009,	// 0000 0000 1001	: PDA Wave		Mono and Stero
	LPMDAFMT_WAV_S		= 0xF00C,	// 0000 0000 1100	: PDA 3d		Sound

	LNMDAFMT_UNKNOWN	= 0xFFFFFFFF,	// 0000 0000 0000	: Loader	Player
};


#endif

