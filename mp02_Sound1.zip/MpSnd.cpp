// Implementation of the CMpSnd class.
//
////////////////////////////////////////////////////////////////////////////////

#if defined(_MSC_VER)
  #pragma warning(disable:4996)
#endif


#include <stdio.h>
#include <windows.h>
#include <mmsystem.h>

#include "ILpSmd.h"
#include "LpSmdBase.h"

#include "MpUtil.h"
#include "MpSnd.h"


#define OFFSET_FORMATTAG			20
#define OFFSET_CHANNELS				22
#define OFFSET_SAMPLESPERSEC		24
#define OFFSET_AVGBYTESPERSEC		28
#define OFFSET_BLOCKALIGN			32
#define OFFSET_BITSPERSAMPLE		34
#define OFFSET_DATASIZE				40
#define OFFSET_WAVEDATA				44
#define HEADER_SIZE	                OFFSET_WAVEDATA



#define SAFE_DELETE(p)			{ if(p){ delete (p);	(p) = NULL; }}
#define SAFE_DELETE_ARRAY(p)	{ if(p){ delete [] (p);	(p) = NULL; }}
#define SAFE_RELEASE(p)			{ if(p){ (p)->Release();(p) = NULL; }}



CMpSnd::CMpSnd()
{
	m_pData		= NULL;
	m_iData		= 0;
	
	memset(&m_WavFMT, 0, sizeof(WAVEFORMATEX) );
	memset(&m_WavOut, 0, sizeof(HWAVEOUT) );
	memset(&m_WavHDR, 0, sizeof(WAVEHDR) );

	m_dVol		= 0;
	m_dRpt		= 1;
	m_dStat		= MEDIA_STATE_STOP;
}


// Desc: Destroys the class

CMpSnd::~CMpSnd()
{
	CMpSnd::Destroy();
}




INT CMpSnd::Create(void* p1, void* p2, void* p3, void* p4)
{
	FILE*	fp	 = NULL;
	TCHAR*	sFile=(TCHAR*)p1;

	TCHAR* p = NULL;

	fp = fopen (sFile, "rb");

    if(!fp)
        return -1;



    // Determine the file size
    fseek(fp, 0, SEEK_END);
    m_iData = ftell(fp);
    // Rewind the pointer to the begginning so we can read it
    fseek(fp, 0, SEEK_SET);

	if(m_iData%4 != 0)
	{
		m_iData+=(4-m_iData%4);
	}

    // Request enough memory to store the entire file
    m_pData = new char [m_iData];
    // 'Copy' the file to memory
    fread(m_pData, 1, m_iData, fp);
    // Close the file, we won't need it anymore
    fclose(fp);

	// Fill WAVEFORMATEX with the data from the file
    m_WavFMT.wFormatTag         = *((WORD* )(m_pData + OFFSET_FORMATTAG     ));
    m_WavFMT.nChannels          = *((WORD* )(m_pData + OFFSET_CHANNELS      ));
    m_WavFMT.nSamplesPerSec     = *((DWORD*)(m_pData + OFFSET_SAMPLESPERSEC ));
    m_WavFMT.nAvgBytesPerSec    = *((DWORD*)(m_pData + OFFSET_AVGBYTESPERSEC));
    m_WavFMT.nBlockAlign        = *((WORD* )(m_pData + OFFSET_BLOCKALIGN    ));
    m_WavFMT.wBitsPerSample     = *((WORD* )(m_pData + OFFSET_BITSPERSAMPLE ));


	// ���ο� ���۸� �����.
	m_WavHDR.lpData			= m_pData + HEADER_SIZE;
	m_WavHDR.dwBufferLength = m_iData - HEADER_SIZE;
	m_WavHDR.dwBufferLength = *((DWORD*)(m_pData + OFFSET_DATASIZE));

	m_WavHDR.dwUser			= (DWORD)this;

	
	if(MMSYSERR_NOERROR != waveOutOpen(
		&m_WavOut
		, WAVE_MAPPER
		, &m_WavFMT
		, (DWORD)CMpSnd::WaveOutProc
		, 0
		, CALLBACK_FUNCTION))
		return -1;

	return 0;
}




void CMpSnd::Destroy()
{
	MMRESULT hr = 0;

	if(MEDIA_STATE_STOP != m_dStat)
		Stop();

	hr = waveOutClose(m_WavOut);

	SAFE_DELETE_ARRAY(	m_pData	);
}


INT CMpSnd::Query(char* sCmd, void* pData)
{
	if(0==_stricmp("Get Repeat", sCmd))
	{
		*((DWORD*)pData) = m_dRpt;
		return 0;
	}

	return -1;
}






DWORD CMpSnd::GetType()
{
	return LP_MDAFMT_WAVE_;
}


void CMpSnd::Play()
{
	MMRESULT hr = 0;

	if(MEDIA_STATE_PLAY == m_dStat)			// Is Playing
		return;

	else if(MEDIA_STATE_STOP == m_dStat)	// Stop
	{
		hr = waveOutPrepareHeader(m_WavOut, &m_WavHDR, sizeof(WAVEHDR));

		if(MMSYSERR_NOERROR != hr)
			return ;
	
		hr = waveOutWrite(m_WavOut, &m_WavHDR, sizeof(WAVEHDR));

		if(MMSYSERR_NOERROR != hr)
			return ;
	}

	else if(MEDIA_STATE_RESET == m_dStat)	// Reset
	{
		hr = waveOutPrepareHeader(m_WavOut, &m_WavHDR, sizeof(WAVEHDR));

		if(MMSYSERR_NOERROR != hr)
			return ;
	
		hr = waveOutWrite(m_WavOut, &m_WavHDR, sizeof(WAVEHDR));

		if(MMSYSERR_NOERROR != hr)
			return ;
	}
	
	else if(MEDIA_STATE_PAUSE == m_dStat)	// Pause
		hr = waveOutRestart(m_WavOut);

	m_dStat	= MEDIA_STATE_PLAY;
}



void CMpSnd::Stop()
{
	MMRESULT hr = 0;

	Reset();

	m_dStat	= MEDIA_STATE_STOP;
	hr = waveOutUnprepareHeader(m_WavOut, &m_WavHDR, sizeof(WAVEHDR));
}


void CMpSnd::Reset()
{
	MMRESULT hr = 0;
	m_dStat = MEDIA_STATE_RESET;

	hr = waveOutReset(m_WavOut);		// WOM_DONE�� ȣ��ȴ�.
}


void CMpSnd::Pause()
{
	MMRESULT hr = 0;
	hr = waveOutPause(m_WavOut);
	m_dStat = MEDIA_STATE_PAUSE;
}


void CMpSnd::SetVolume(LONG dVol)
{
	m_dVol = dVol;
	waveOutSetVolume(m_WavOut, m_dVol);
}


LONG CMpSnd::GetVolume()
{
	return m_dVol;
}


void CMpSnd::SetRepeat(DWORD dRepeat)
{
	m_dRpt = dRepeat;
}



DWORD CMpSnd::GetStatus()
{
	return m_dStat;
}


void CMpSnd::SetStatus(DWORD dSt)
{
	m_dStat = dSt;
}


DWORD CMpSnd::GetRepeat()
{
	return m_dRpt;
}


void CALLBACK CMpSnd::WaveOutProc(HWAVEOUT hWavOut, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2)
{
	switch(uMsg)
	{
		case WOM_OPEN:
			break;

		// Play�� waveOutReset�� ȣ���ϸ� WOM_DONE �̺�Ʈ �߻�
		case WOM_DONE:
		{
			WAVEHDR*	pWavHDR = (WAVEHDR*)dwParam1;
			CMpSnd*		pSnd	= (CMpSnd*)(pWavHDR->dwUser);

			DWORD		dRepeat = 0;
			DWORD		dState = 0;

			MMRESULT hr = 0;

			dState = pSnd->GetStatus();

			if(MEDIA_STATE_PLAY == dState)
			{
				pSnd->SetStatus(MEDIA_STATE_STOP);

				dRepeat = pSnd->GetRepeat();

				if(0xFFFFFFFF == dRepeat)
				{
					pSnd->Play();
				}
			}

			break;
		}

		case WOM_CLOSE:
			break;
	}
}



