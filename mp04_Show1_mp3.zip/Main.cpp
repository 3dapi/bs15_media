// Implementation of the CMain class.
//
//////////////////////////////////////////////////////////////////////////////

#define _WIN32_WINNT	0x400

#include "_StdAfx.h"


CMain::CMain()
{
	m_pMp1		= NULL;
	m_pMp2		= NULL;
	m_pMp3		= NULL;
}


INT CMain::Init()
{
	//We need Initialize COM(must be defined _WIN32_WINNT	over 0x400)
	if(FAILED(CoInitializeEx(NULL, COINIT_APARTMENTTHREADED)))
		return -1;
	
	
//	m_pMp1 = new CMiMp3;
//	m_pMp1->Create("Sound/s1.wav");

//	m_pMp2 = new CMiMp3;
//	m_pMp2->Create("Sound/track2.mp3");
//
	m_pMp3 = new CMiMp3;
	m_pMp3->Create("Sound/s1.wav");

//	m_pMp1->Play();
//	m_pMp2->Play();
	m_pMp3->Play();
	
	return 0;
}

void CMain::Destroy()
{
	SAFE_DELETE(	m_pMp1		);
	SAFE_DELETE(	m_pMp2		);
	SAFE_DELETE(	m_pMp3		);

	// Release COM
	CoUninitialize();
}




INT CMain::Restore()
{
	return 0;
}


void CMain::Invalidate()
{
}


INT CMain::FrameMove()
{
	if(GetAsyncKeyState('A') & 0x8000)
	{
		m_pMp3->Play();
	}

	if(GetAsyncKeyState('P') & 0x8000)
	{
		m_pMp3->Pause();
	}

	if(GetAsyncKeyState('R') & 0x8000)
	{
		m_pMp3->Reset();
	}

	if(GetAsyncKeyState('S') & 0x8000)
	{
		m_pMp3->Stop();
	}

	return 0;
}


INT CMain::Render()
{
	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xFF006699, 1.0f, 0 );
	
	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;
	
	
	// EndScene
	m_pd3dDevice->EndScene();
	
	return 0;
}


LRESULT CMain::MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch( msg )
	{
		case WM_DSHOW_EVENT:
		{
			CMiMp3* pMp3 = (CMiMp3*)lParam;
			pMp3->ProcessEvent();
			break;
		}


		case WM_PAINT:
		{
			break;
		}
	}
	
	return CApplication::MsgProc( hWnd, msg, wParam, lParam );
}