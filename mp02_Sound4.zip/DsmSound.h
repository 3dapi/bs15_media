// Utilities for Direct Sound.
// Modified by Heesung Oh (2007-10-04)
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _DsmUtil_H_
#define _DsmUtil_H_


////////////////////////////////////////////////////////////////////////////////
// Sound Utilitiy functions.

// Sound Manager Create
INT LnSnd_ManagerCreate(HWND  hWnd						// window Handle
						, DWORD dPrimaryChannels= 2		// 2 is stero
						, DWORD dPrimaryFreq	= 22050	// primary buffer 22kHz
						, DWORD dPrimaryBitRate	= 16	// 16-bit
						);


// Sound Manager Destroy
void LnSnd_ManagerDestroy();


// Sound Create By Manager
HANDLE	LnSnd_Create(char* sFileName /* File Name*/ );


// Sound Destroy
void	LnSnd_Destroy(HANDLE s);


// Sound stop
void	LnSnd_Stop(HANDLE s);


// Sound Play one time
void	LnSnd_Play(HANDLE s);


// Sound Play Infinite
void	LnSnd_PlayLooping(HANDLE s);


//
////////////////////////////////////////////////////////////////////////////////






////////////////////////////////////////////////////////////////////////////////
// Interface for the CDsmSound class.

#pragma comment(lib, "dxguid.lib")
#pragma comment(lib, "dsound.lib")												// Direct Sound


#include <windows.h>
#include <mmsystem.h>
#include <mmreg.h>
#include <dsound.h>


class CDsmSound
{
public:

	// Encapsulates reading or writing sound data to or from a wave file
	struct DWaveFile
	{
		WAVEFORMATEX* m_pwfx;        // Pointer to WAVEFORMATEX structure
		HMMIO         m_hmmio;       // MM I/O handle for the WAVE
		MMCKINFO      m_ck;          // Multimedia RIFF chunk
		MMCKINFO      m_ckRiff;      // Use in opening a WAVE file
		DWORD         m_dwSize;      // The size of the wave file
		MMIOINFO      m_mmioinfoOut;
		DWORD         m_dwFlags;
		BOOL          m_bIsReadingFromMemory;
		BYTE*         m_pbData;
		BYTE*         m_pbDataCur;
		ULONG         m_ulDataSize;
		CHAR*         m_pResourceBuffer;
		
		HRESULT ReadMMIO();
		HRESULT WriteMMIO( WAVEFORMATEX *pwfxDest );
		
		DWaveFile();
		~DWaveFile();
		
		HRESULT Open( LPTSTR strFileName
					, WAVEFORMATEX* pwfx
					, DWORD dwFlags );

		HRESULT OpenFromMemory( BYTE* pbData
							, ULONG ulDataSize
							, WAVEFORMATEX* pwfx
							, DWORD dwFlags );
		HRESULT Close();
		
		HRESULT Read( BYTE* pBuffer, DWORD dwSizeToRead, DWORD* pdwSizeRead );
		HRESULT Write( UINT nSizeToWrite, BYTE* pbData, UINT* pnSizeWrote );
		
		DWORD   GetSize();
		HRESULT ResetFile();
		WAVEFORMATEX* GetFormat() { return m_pwfx; };
	}; //struct DWaveFile


	
	class DSound
	{
	protected:
		LPDIRECTSOUNDBUFFER* m_apDSBuffer;
		DWORD                m_dwDSBufferSize;
		DWaveFile*           m_pWaveFile;
		DWORD                m_dwNumBuffers;
		DWORD                m_dwCreationFlags;
		
		HRESULT RestoreBuffer( LPDIRECTSOUNDBUFFER pDSB
							, BOOL* pbWasRestored );
		
	public:
		DSound( LPDIRECTSOUNDBUFFER* apDSBuffer
			, DWORD dwDSBufferSize
				, DWORD dwNumBuffers
				, DWaveFile* pWaveFile
				, DWORD dwCreationFlags );

		virtual ~DSound();
		
		HRESULT FillBufferWithSound( LPDIRECTSOUNDBUFFER pDSB
									, BOOL bRepeatWavIfBufferLarger );

		LPDIRECTSOUNDBUFFER GetFreeBuffer();
		LPDIRECTSOUNDBUFFER GetBuffer( DWORD dwIndex );
		
		HRESULT Play( DWORD dwFlags = 0
					, DWORD dwPriority = 0
					, LONG lVolume = 0
					, LONG lFrequency = -1
					, LONG lPan = 0 );

		HRESULT Stop();
		HRESULT Reset();
		BOOL    IsSoundPlaying();
		void	SetVolume(LONG lVal);
		LONG	GetVolume();
	}; //class DSound

	
	protected:
		LPDIRECTSOUND8 m_pDS;

	public:
		static CDsmSound* m_pSoundMng;
		
	public:
		CDsmSound();
		~CDsmSound();
		
		HRESULT Create( HWND hWnd, DWORD dwCoopLevel );
		inline  LPDIRECTSOUND8 GetDirectSound() { return m_pDS; }

		HRESULT SetPrimaryBufferFormat( DWORD dwPrimaryChannels
									, DWORD dwPrimaryFreq
									, DWORD dwPrimaryBitRate );
		
		HRESULT Create( DSound** ppSound
						, LPTSTR strWaveFileName
						, DWORD dwCreationFlags = 0
						, GUID guid3DAlgorithm = GUID_NULL
						, DWORD dwNumBuffers = 1 );

		HRESULT CreateFromMemory( DSound** ppSound
						, BYTE* pbData
						, ULONG ulDataSize
						, LPWAVEFORMATEX pwfx
						, DWORD dwCreationFlags = 0
						, GUID guid3DAlgorithm = GUID_NULL
						, DWORD dwNumBuffers = 1 );
};


#endif


