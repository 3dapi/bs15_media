// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pSoundDing	= NULL;
	m_pSoundT		= NULL;
}


INT CMain::Init()
{
	if(FAILED(LnSnd_ManagerCreate(m_hWnd)))
		return -1;
	
	
	m_pSoundDing = LnSnd_Create("Sound/ding.wav");
	
	if(NULL == m_pSoundDing)
		return -1;


	m_pSoundT = LnSnd_Create("Sound/tsound1.wav");
	
	if(NULL == m_pSoundT)
		return -1;


	return 0;
}

void CMain::Destroy()
{
	LnSnd_Destroy(m_pSoundDing);
	LnSnd_Destroy(m_pSoundT	);

	LnSnd_ManagerDestroy();
}




INT CMain::Restore()
{
	return 0;
}


void CMain::Invalidate()
{
}


INT CMain::FrameMove()
{
	if(::GetAsyncKeyState('Q') & 0x8000)
	{
		LnSnd_Play(m_pSoundDing);
	}

	if(::GetAsyncKeyState('W') & 0x8000)
	{
		LnSnd_PlayLooping(m_pSoundT);
	}

	if(::GetAsyncKeyState('S') & 0x8000)
	{
		LnSnd_Stop(m_pSoundT);
	}

	
	
	return 0;
}


INT CMain::Render()
{
	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xFF006699, 1.0f, 0 );

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;


	// EndScene
	m_pd3dDevice->EndScene();

	TCHAR	sMsg[128];
	sprintf(sMsg, "���� Test Press Q, W, S Key         FPS: %4.1f", m_fFps);
	SetWindowText(m_hWnd, sMsg);

	return 0;
}


LRESULT CMain::MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch( msg )
	{
		case WM_PAINT:
		{
			break;
		}
	}
	
	return CApplication::MsgProc( hWnd, msg, wParam, lParam );
}