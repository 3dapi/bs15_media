// Interface for the CDxMusic class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _DXMUSIC_H_
#define _DXMUSIC_H_


struct DxMusic  
{
	IDirectMusicLoader8*		pDLoader;			// the Loader
	IDirectMusicPerformance8*	pPerform;			// the Performance
	IDirectMusicSegment8*		pSegment;			// the Segment

	MUSIC_TIME					mtPause;

	DxMusic();
	~DxMusic();

	void	Play();
	void	Stop();
	void	Reset();
	void	Pause();

	void	SetRepeat(DWORD dRepeat= DMUS_SEG_REPEAT_INFINITE);
};


class CDxMusicManager
{
protected:
	IDirectMusicLoader8*		m_pLoader ;			// the loader
	
public:
	CDxMusicManager();
	virtual ~CDxMusicManager();

	INT		Init();
	void	Destroy();
	INT		Create(DxMusic** pMusic, char* sFile);								// From File
	INT		Create(DxMusic** pMusic, INT nResourceID, char* sResourceType);		// From Resource
};

MUSIC_TIME DmUtil_GetTimeOffset(IDirectMusicPerformance8* pPerform, IDirectMusicSegment8* pSegment);

#endif