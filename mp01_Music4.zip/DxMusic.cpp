// Implementation of the DxMusic class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


DxMusic::DxMusic()
{
	pDLoader	= NULL;
	pPerform	= NULL;
	pSegment	= NULL;

	mtPause		= 0;
}


DxMusic::~DxMusic()
{
	Stop();

	if(pSegment)
	{
		pSegment->Release();
		pSegment = NULL;
	}

	// close down the performance
	if(pPerform)
	{
		pPerform->Stop(NULL, NULL, 0, 0);
		pPerform->CloseDown();
		pPerform->Release();
		pPerform = NULL;
	}
}


void DxMusic::Play()
{
	pSegment->SetStartPoint(mtPause);
	pPerform->PlaySegmentEx(pSegment, NULL, NULL, 0, 0, NULL, NULL, NULL);
}

void DxMusic::Stop()
{
	if(S_OK == pPerform->IsPlaying(pSegment, NULL))
		pPerform->StopEx(pSegment, 0, 0);

	mtPause	= 0;
}

void DxMusic::Reset()
{
	mtPause	= 0;
}


void DxMusic::SetRepeat(DWORD dRepeat)
{
	pSegment->SetRepeats(dRepeat);
}


void DxMusic::Pause()
{
	if(S_OK == pPerform->IsPlaying(pSegment, NULL))
	{
		mtPause = DmUtil_GetTimeOffset(pPerform, pSegment);
		pPerform->StopEx(pSegment, 0, 0);
	}
}



// Implementation of the CDxMusicManager class.
//
////////////////////////////////////////////////////////////////////////////////


CDxMusicManager::CDxMusicManager()
{
	m_pLoader	= NULL;
}


CDxMusicManager::~CDxMusicManager()
{
	Destroy();
}


INT CDxMusicManager::Init()
{
	HWND hWnd = GetActiveWindow();

	if (FAILED(CoInitialize(NULL)))
		return -1;


	if (FAILED(CoCreateInstance(CLSID_DirectMusicLoader, NULL, CLSCTX_INPROC, IID_IDirectMusicLoader8, (void**)&m_pLoader)))
	{
		MessageBox(hWnd, "Create IDirectMusicLoader8 Failed", "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	char pathStr[MAX_PATH];
	WCHAR wsFile[MAX_PATH];

	GetCurrentDirectory(MAX_PATH, pathStr);
	MultiByteToWideChar(CP_ACP, 0, pathStr, -1, wsFile, MAX_PATH);
	m_pLoader->SetSearchDirectory(GUID_DirectMusicAllTypes, wsFile, FALSE);

	return 1;
}



INT CDxMusicManager::Create(DxMusic** pMusic, char* sFile)						// ���Ͽ��� ���� ����
{
	HRESULT	hr;
	HWND	hWnd = GetActiveWindow();

	IDirectMusicSegment8*		pSegment	= NULL;
	IDirectMusicPerformance8*	pPerform	= NULL;


	if (FAILED(CoCreateInstance(CLSID_DirectMusicPerformance, NULL, CLSCTX_INPROC, IID_IDirectMusicPerformance8, (void**)&pPerform)))
		return -1;

	if(FAILED(pPerform->InitAudio(NULL, NULL, hWnd, DMUS_APATH_SHARED_STEREOPLUSREVERB, 128, DMUS_AUDIOF_ALL, NULL)))
		return -1;


	WCHAR	wsFile[MAX_PATH];
	MultiByteToWideChar(CP_ACP, 0, sFile, -1, wsFile, MAX_PATH);

	if (FAILED(hr = m_pLoader->LoadObjectFromFile(CLSID_DirectMusicSegment,	IID_IDirectMusicSegment8,	wsFile,	(void**)&pSegment)))
	{
		MessageBox(hWnd, "Load Music File Failed", "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	pSegment->Download(pPerform);

	(*pMusic) = new DxMusic;
	(*pMusic)->pDLoader	= this->m_pLoader;
	(*pMusic)->pPerform	= pPerform;
	(*pMusic)->pSegment	= pSegment;

	return 1;
}




INT CDxMusicManager::Create(DxMusic** pMusic, INT nRscID, char* sRscType)		// ���ҽ����� ���� �����
{
	HRESULT	hr;
	HWND	hWnd = GetActiveWindow();


	IDirectMusicSegment8*		pSegment	= NULL;
	IDirectMusicPerformance8*	pPerform	= NULL;


	if (FAILED(CoCreateInstance(CLSID_DirectMusicPerformance, NULL, CLSCTX_INPROC, IID_IDirectMusicPerformance8, (void**)&pPerform)))
		return -1;

	if(FAILED(pPerform->InitAudio(NULL, NULL, hWnd, DMUS_APATH_SHARED_STEREOPLUSREVERB, 128, DMUS_AUDIOF_ALL, NULL)))
		return -1;




	HINSTANCE				hInst		= GetModuleHandle(NULL);
	HRSRC					hres		= NULL;
	void*					pMem		= NULL;
	DWORD					dwSize		= 0;
	DMUS_OBJECTDESC			objdesc;


	hres = FindResource( hInst,MAKEINTRESOURCE(nRscID), sRscType );	// Find the resource

	if( NULL == hres )
		return -1;

	pMem = (void*)LoadResource( hInst, hres );									// Load the resource

	if( NULL == pMem )
		return -1;

	dwSize = SizeofResource( NULL, hres );										// Size of the resource


	// Set up
	ZeroMemory(&objdesc,sizeof(DMUS_OBJECTDESC));
	objdesc.dwSize = sizeof(DMUS_OBJECTDESC);
	objdesc.dwValidData = DMUS_OBJ_MEMORY | DMUS_OBJ_CLASS;
	objdesc.guidClass = CLSID_DirectMusicSegment;
	objdesc.llMemLength =(LONGLONG)dwSize;
	objdesc.pbMemData = (BYTE*)pMem;

	if(FAILED( hr = m_pLoader->GetObject( &objdesc, IID_IDirectMusicSegment8, (void**)&pSegment )))
		return -1;


	pSegment->Download(pPerform);

	(*pMusic) = new DxMusic;
	(*pMusic)->pDLoader	= this->m_pLoader;
	(*pMusic)->pPerform	= pPerform;
	(*pMusic)->pSegment	= pSegment;

	return 1;
}







void CDxMusicManager::Destroy()
{
	if(m_pLoader)
	{
		m_pLoader->Release();
		m_pLoader = NULL;
	}

	CoUninitialize();
}





// From http://www.GameDev.net

MUSIC_TIME DmUtil_GetTimeOffset(IDirectMusicPerformance8* pPerform, IDirectMusicSegment8* pSegment)
{

	IDirectMusicSegmentState*	pSegState = NULL;
	MUSIC_TIME mtNow;           // From GetTime
	MUSIC_TIME mtStartTime;     // From GetStartTime
	MUSIC_TIME mtStartPoint;    // From GetStartPoint
	MUSIC_TIME mtLoopStart;     // From GetLoopPoints
	MUSIC_TIME mtLoopEnd;       // From GetLoopPoints
	MUSIC_TIME mtLength;        // From GetLength
	DWORD dwLoopRepeats;        // From GetRepeats

	//	pSegment->GetTime		(&mtNow);
	//	pSegment->GetStartTime	(&mtStartTime);
	//	pSegment->GetStartPoint	(&mtStartPoint);
	//	pSegment->GetLoopPoints	(&mtLoopStart, &mtLoopEnd);
	//	pSegment->GetLength		(&mtLength);
	//	pSegment->GetRepeats	(&dwLoopRepeats);

	pPerform ->GetTime(NULL, &mtNow);
	pPerform ->GetSegmentState(&pSegState, mtNow);
	pSegState->GetStartPoint(&mtStartPoint);
	pSegState->GetStartTime(&mtStartTime);
	pSegment ->GetLoopPoints(&mtLoopStart, &mtLoopEnd);
	pSegment ->GetRepeats(&dwLoopRepeats);

	//	if(thisAudio->audioType == WAV)
	//		pSegment->SetLength(mtNow);

	pSegment->GetLength(&mtLength);

	// Convert mtNow from absolute time to an offset
	// from when the segment started playing
	LONGLONG llOffset = mtNow - (mtStartTime - mtStartPoint);

	// If loopEnd is non zero, set lLoopEnd to loopEnd,
	// otherwise use the segment length
	LONGLONG llLoopEnd = mtLoopEnd ? mtLoopEnd : mtLength;
	LONGLONG llLoopStart = mtLoopStart;

	if((dwLoopRepeats != 0) && (llLoopStart < llLoopEnd) && (llLoopEnd > mtStartPoint))
	{
		if((dwLoopRepeats != DMUS_SEG_REPEAT_INFINITE) && (llOffset > (llLoopStart + (llLoopEnd - llLoopStart) * (signed)dwLoopRepeats)))
		{
			llOffset -= (llLoopEnd - llLoopStart) * dwLoopRepeats;
		}
		else if( llOffset > llLoopStart )
		{
			llOffset = llLoopStart + (llOffset - llLoopStart) % (llLoopEnd - llLoopStart);
		}
	}

	llOffset = min( llOffset, LONG_MAX );	// LONG_MAX is defined in Limits.h.

	return MUSIC_TIME(llOffset);
}