// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pDxMusic1		= NULL;

	m_pMusicManager = NULL;
}


INT CMain::Init()
{
	// Music �Ŵ����� �����.
	m_pMusicManager = new CDxMusicManager;

	if(FAILED(m_pMusicManager->Init()))
		return -1;
	

	// Music�� �Ŵ����� ���ؼ� �����.
	if(FAILED(m_pMusicManager->Create(&m_pDxMusic1, "Sound/CANYON.MID")))
		return -1;

	m_pDxMusic1->Play();

	return 0;
}

void CMain::Destroy()
{
	SAFE_DELETE(	m_pDxMusic1		);
	SAFE_DELETE(	m_pMusicManager	);
}




INT CMain::Restore()
{
	return 0;
}


void CMain::Invalidate()
{
}


INT CMain::FrameMove()
{
	if( (GetAsyncKeyState( '1' ) & 0x8000) == 0x8000)		m_pDxMusic1->Pause();
	if( (GetAsyncKeyState( '2' ) & 0x8000) == 0x8000)		m_pDxMusic1->Play();
	if( (GetAsyncKeyState( '3' ) & 0x8000) == 0x8000)		m_pDxMusic1->Stop();
	
	return 0;
}


INT CMain::Render()
{
	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xFF006699, 1.0f, 0 );

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	// EndScene
	m_pd3dDevice->EndScene();

	TCHAR	sMsg[128];
	sprintf(sMsg, "Sound Test Press F11 Key         FPS: %4.1f", m_fFps);
	SetWindowText(m_hWnd, sMsg);

	return 0;
}


LRESULT CMain::MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch( msg )
	{
		case WM_PAINT:
		{
			break;
		}
	}
	
	return CApplication::MsgProc( hWnd, msg, wParam, lParam );
}