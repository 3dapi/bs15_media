// Implementation of the CMcDShow  class.
//
////////////////////////////////////////////////////////////////////////////////

// Need DShowStrmBase.lib....
// You must be copy below codes..

// Begin------------------------------------------------------------------------
	#ifdef _DEBUG
	#pragma comment(lib, "DShowStrmbase_.lib")
	#else
	#pragma comment(lib, "DShowStrmbase.lib")
	#endif
// End--------------------------------------------------------------------------


#pragma warning(disable:4996)

#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


#include <windows.h>
#include <mmsystem.h>
#include <atlbase.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include <streams.h>

#include "McDShow.h"


// Define GUID for Texture Renderer {71771540-2017-11cf-AE26-0020AFD79767}
struct __declspec(uuid("{71771540-2017-11cf-ae26-0020afd79767}")) CLSID_TextureRenderer;


typedef	LPDIRECT3DDEVICE9		PDEV;
typedef	LPDIRECT3DTEXTURE9		PDTX;



class TShowRender : public CBaseVideoRenderer
{
public:
	PDTX		m_pTex;
	LONG		m_avW;													// Video width
	LONG		m_avH;													// Video Height
	LONG		m_avD;													// Video Height
	
public:
	TShowRender(LPUNKNOWN pUnk,HRESULT *phr);
	virtual ~TShowRender();
	
	HRESULT		CheckMediaType(const CMediaType *pmt );					// Format acceptable?
	HRESULT		SetMediaType(const CMediaType *pmt );					// Video format notification
	HRESULT		DoRenderSample(IMediaSample *pMediaSample);				// New video sample
};


class TShowClip
{
protected:
	char		m_sFile[MAX_PATH];
	PDEV		m_pDev;

	DWORD		m_dRepeat;												// 0xFFFFFFFF == Infinite
	DWORD		m_dRptCnt;
	
public:
	IGraphBuilder*		m_pGB;											// GraphBuilder
	IMediaControl*		m_pMC;											// Media Control
	IMediaPosition*		m_pMP;											// Media Position
	IMediaEventEx*		m_pME;											// Media Event
	TShowRender*		m_pSR;											// DirectShow Texture renderer
	
public:
	TShowClip();
	virtual ~TShowClip();
	
	INT		Create(PDEV pDev, char* sFile);
	void	Destroy();
	
	INT		ProcessEvent();

	INT	Stop()
	{
		if(m_pMC)
			m_pMC->Stop();

		return 0;
	}

	INT Reset()
	{
		return 0;
	}

	
	PDTX GetTexture()
	{
		if(m_pSR)
			return m_pSR->m_pTex;

		return 0;
	}

	INT GetVidWidth()
	{
		if(m_pSR)
			return m_pSR->m_avW;

		return 0;
	}

	INT GetVidHeight()
	{
		if(m_pSR)
			return m_pSR->m_avH;

		return 0;
	}

	INT GetVidDepth()
	{
		if(m_pSR)
			return m_pSR->m_avD;

		return 0;
	}
};


static BYTE g_workAvBuf[2048 * 2048* 4]={0};

////////////////////////////////////////////////////////////////////////////////
// TShowRender

TShowRender::TShowRender( LPUNKNOWN pUnk, HRESULT *phr)
: CBaseVideoRenderer(__uuidof(CLSID_TextureRenderer), NAME("Texture Renderer"), pUnk, phr)
{
	ASSERT(phr);
	if (phr)
		*phr = S_OK;
	
}



// TShowRender destructor

TShowRender::~TShowRender()
{
	// Do nothing
}


HRESULT TShowRender::CheckMediaType(const CMediaType *pmt)
{
	HRESULT   hr = -1;
	VIDEOINFO *pvi=0;
	
	CheckPointer(pmt,E_POINTER);
	
	// Reject the connection if this is not a video type
	if( *pmt->FormatType() != FORMAT_VideoInfo )
	{
		return E_INVALIDARG;
	}
	
	// Only accept RGB24 video
	pvi = (VIDEOINFO *)pmt->Format();
	
	if(IsEqualGUID( *pmt->Type(),    MEDIATYPE_Video)  &&
		IsEqualGUID( *pmt->Subtype(), MEDIASUBTYPE_RGB24))
	{
		hr = S_OK;
	}
	
	return hr;
}


HRESULT TShowRender::SetMediaType(const CMediaType *pmt)
{
	UINT uintWidth = 2;
	UINT uintHeight = 2;
	
	// Retrive the size of this media type
	
	VIDEOINFO *pviBmp;                      // Bitmap info header
	pviBmp = (VIDEOINFO *)pmt->Format();
	
	m_avW  = pviBmp->bmiHeader.biWidth;
	m_avH = abs(pviBmp->bmiHeader.biHeight);
	m_avD = pviBmp->bmiHeader.biBitCount/8;

	return S_OK;
}


// DoRenderSample: A sample has been delivered. Copy it to the texture.

HRESULT TShowRender::DoRenderSample( IMediaSample * pSample )
{
	BYTE*	pSrc;		// source Bitmap
	BYTE*	pDst;		// dest texture buffer
	
	INT row, col;
	
	CheckPointer(pSample,E_POINTER);
	CheckPointer(m_pTex,E_UNEXPECTED);
	
	// Get the video bitmap buffer
	pSample->GetPointer( &pSrc );


	for(row = 0; row< m_avH; ++row)
	{
		//pDst = &g_workAvBuf[row * m_avW * 4];
		pDst = &g_workAvBuf[(m_avH-row-1) * m_avW * 4];

		for(col = 0; col < m_avW; ++col)
		{
			*(pDst++) = *(pSrc++);
			*(pDst++) = *(pSrc++);
			*(pDst++) = *(pSrc++);
			*(pDst++) = 0XFF;
		}
	}



	// copy the rendering pixe to dest texture buffer
	D3DLOCKED_RECT rc;
	if( FAILED(m_pTex->LockRect(0, &rc, 0, 0)))
		return -1;
	
	pDst = (BYTE*)rc.pBits;
	memcpy(pDst, g_workAvBuf, m_avW * m_avH * sizeof(DWORD));	// COLOR Is rgba so, needs UINT or DWORD
	
	if (FAILED(m_pTex->UnlockRect(0)))
		return -1;
	
	return S_OK;
}



////////////////////////////////////////////////////////////////////////////////
// TShowClip

TShowClip::TShowClip()
{
	m_pDev		= NULL;

	m_dRepeat	= 0xFFFFFFFF;
	m_dRptCnt	= 0x0;

	memset(m_sFile, 0, sizeof m_sFile);
}



TShowClip::~TShowClip()
{
	Destroy();
}


void TShowClip::Destroy()
{
	Stop();

	m_pME->SetNotifyWindow((OAHWND)NULL, 0, 0);

	SAFE_RELEASE(	m_pSR->m_pTex	);

	SAFE_RELEASE(	m_pMC	);
	SAFE_RELEASE(	m_pMP	);
	SAFE_RELEASE(	m_pME	);
	SAFE_RELEASE(	m_pGB	);
}


INT	 TShowClip::Create(PDEV pDev, char* sFile)
{
	HRESULT hr	= S_OK;
	HWND hWnd	= NULL;
	D3DDEVICE_CREATION_PARAMETERS pParam;

	WCHAR wFileName[MAX_PATH]={0};

	IBaseFilter*    pFSrc;          // Source Filter
	IPin*           pFSrcPinOut;    // Source Filter Output Pin   


	m_pDev = pDev;
	m_pDev->GetCreationParameters( &pParam);
	hWnd = pParam.hFocusWindow;
	strcpy(m_sFile, sFile);
	

	// Initialize COM
	CoInitialize (NULL);
	
	
	
	// Create the filter graph
	if(FAILED(CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC, __uuidof(IGraphBuilder), (void**)&m_pGB)))
		return -1;
	
	// Create the Texture Renderer object
	m_pSR = new TShowRender(NULL, &hr);
	
	
	// Get a pointer to the IBaseFilter on the TextureRenderer, add it to graph
	if (FAILED(hr = m_pGB->AddFilter(m_pSR, L"TEXTURERENDERER")))
	{
		MessageBox(hWnd, "Could not add renderer filter to graph", "Err", MB_ICONEXCLAMATION);
		return -1;
	}
	
	// Rename File... to Wide Character
	MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, sFile, strlen(sFile), wFileName, MAX_PATH);
	

	// Add the source filter to the graph.
	hr = m_pGB->AddSourceFilter (wFileName, L"SOURCE", &pFSrc);
	
	// If the media file was not found, inform the user.
	if(FAILED(hr) || hr == VFW_E_NOT_FOUND)
	{
		MessageBox(hWnd, "Could not add source filter to graph", "Err", MB_ICONEXCLAMATION);
		return -1;
	}

	// Find Pin
	if(FAILED(hr = pFSrc->FindPin(L"Output", &pFSrcPinOut)))
	{
		MessageBox(hWnd, "Could not output pin", "Err", MB_ICONEXCLAMATION);
		return -1;
	}
	
	
	// Render the source filter's output pin.  The Filter Graph Manager
	// will connect the video stream to the loaded TShowRender
	// and will load and connect an audio renderer (if needed).
	hr = m_pGB->Render(pFSrcPinOut);
	if(FAILED(hr))
	{
		MessageBox(hWnd, "Could not render source output pin", "Err", MB_ICONEXCLAMATION);
		return -1;
	}
	

	// Get the graph's media control, event & position interfaces
	hr = m_pGB->QueryInterface(__uuidof(IMediaControl), (void**)&m_pMC);
	hr = m_pGB->QueryInterface(__uuidof(IMediaPosition), (void**)&m_pMP);
	hr = m_pGB->QueryInterface(__uuidof(IMediaEventEx), (void**)&m_pME);

	// Set Window Event Notification
	m_pME->SetNotifyWindow((OAHWND)hWnd, WM_DSHOW_EVENT, (LONG)this);





	long avW = m_pSR->m_avW;
	long avH = m_pSR->m_avH; 
	hr = m_pDev->CreateTexture(avW, avH, 1, 0, D3DFMT_X8R8G8B8,D3DPOOL_MANAGED,	&m_pSR->m_pTex, NULL);
	
	if( FAILED(hr))
	{
		MessageBox(hWnd, "Could not create the DShow texture", "Err", MB_ICONEXCLAMATION);
		return -1;
	}


	// Start the graph running;
	if (FAILED(hr = m_pMC->Run()))
	{
		MessageBox(hWnd, "Could not run the DirectShow graph", "Err", MB_ICONEXCLAMATION);
		return -1;
	}
	
	return 0;
}


INT TShowClip::ProcessEvent()
{
	long lEventCode;
	long lParam1;
	long lParam2;
	HRESULT hr;
	
	if (!m_pME)
		return 0;
	
	// Check for completion events
	hr = m_pME->GetEvent(&lEventCode, (LONG_PTR *) &lParam1, (LONG_PTR *) &lParam2, 0);

	if (SUCCEEDED(hr))
	{
		// If we have reached the end of the media file, reset to beginning
		if (EC_COMPLETE == lEventCode) 
		{
			++m_dRptCnt;

			if(0xFFFFFFFF == m_dRepeat)
				hr = m_pMP->put_CurrentPosition(0);

			hr = m_pME->FreeEventParams(lEventCode, lParam1, lParam2);
			
			if( m_pSR &&
				m_pSR->m_pTex &&
				(m_dRptCnt>m_dRepeat) && 0xFFFFFFFF != m_dRepeat)
			{
				m_pSR->m_pTex->Release();
				m_pSR->m_pTex = NULL;

				return -1;
			}
			

		}
		
		// Free any memory associated with this event
		hr = m_pME->FreeEventParams(lEventCode, lParam1, lParam2);
	}
	
	return 0;
}


////////////////////////////////////////////////////////////////////////////////
// CMcDShow

CMcDShow::CMcDShow()
{
	m_pDev		= NULL;
	m_pVid		= NULL;
}

CMcDShow::~CMcDShow()
{
	Destroy();	
}


INT CMcDShow::Create(PDEV pDev, char* sFile)
{
	m_pDev = pDev;
	
	if(!m_pVid)
	{
		TShowClip* pVid = new TShowClip;
		
		if(FAILED(pVid->Create(pDev, sFile)))
			return -1;

		m_pVid = pVid;
	}
	
	return 0;
}

void CMcDShow::Destroy()
{
	if(m_pVid)
	{
		delete m_pVid;
		m_pVid = NULL;
	}
}


INT CMcDShow::FrameMove()
{
	if(m_pVid)
	{
		TShowClip* pVid = (TShowClip*)m_pVid;
		return pVid->ProcessEvent();
	}
	
	return 0;
}


PDTX CMcDShow::GetTexture()
{
	if(m_pVid)
	{
		TShowClip* pVid = (TShowClip*)m_pVid;
		return pVid->GetTexture();
	}
	
	return NULL;
}



INT CMcDShow::GetVidWidth()
{
	if(m_pVid)
	{
		TShowClip* pVid = (TShowClip*)m_pVid;
		return pVid->GetVidWidth();
	}

	return 0;
}

INT CMcDShow::GetVidHeight()
{
	if(m_pVid)
	{
		TShowClip* pVid = (TShowClip*)m_pVid;
		return pVid->GetVidHeight();
	}

	return 0;
}


INT CMcDShow::GetVidDepth()
{
	if(m_pVid)
	{
		TShowClip* pVid = (TShowClip*)m_pVid;
		return pVid->GetVidDepth();
	}

	return 0;
}
