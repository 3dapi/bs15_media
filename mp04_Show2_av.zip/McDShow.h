// Interface for the CMcDShow  class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCDSHOW_H_
#define _MCDSHOW_H_


#define WM_DSHOW_EVENT		(WM_USER+800)

class CMcDShow
{
protected:
	LPDIRECT3DDEVICE9	m_pDev;
	void*				m_pVid;

public:
	CMcDShow();
	virtual ~CMcDShow();

	INT		Create(LPDIRECT3DDEVICE9 pDev, char* sFile);
	void	Destroy();

	INT		FrameMove();
	
	LPDIRECT3DTEXTURE9 GetTexture();

	INT		GetVidWidth();
	INT		GetVidHeight();
	INT		GetVidDepth();
};

#endif