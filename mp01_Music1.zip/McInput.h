// Interface for the CMcInput class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCINPUT_H_
#define _MCINPUT_H_

class CMcInput  
{
protected:
	BYTE			m_KeyCur[256]	;											// Current Keyboard
	BYTE			m_KeyOld[256]	;											// Old Keyboard
	
	BYTE			m_KeyMap[256]	;											// Key Map down: 1, up: 2, Press 3
	BYTE			m_BtnMap[8]		;											// Button Map

	POINT			m_pt;

public:
	CMcInput();
	virtual ~CMcInput();

	INT		FrameMove();

	BYTE*	GetKeyMap()	const;
	BOOL	KeyDown(INT nKey);
	BOOL	KeyUp(INT nKey);
	BOOL	KeyPress(INT nKey);
	INT		KeyState(int nKey);

	BOOL	ButtonDown(INT nBtn);
	BOOL	ButtonUp(INT nBtn);
	BOOL	ButtonPress(INT nBtn);
};

#endif