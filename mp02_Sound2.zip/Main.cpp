// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pDS	= NULL;
}


INT CMain::Init()
{
	// IDirectSound ��ü ����
	if( FAILED(DirectSoundCreate8( NULL, &m_pDS, NULL ) ) )
		return -1;
	
	// ���·��� ����
	if( FAILED(m_pDS->SetCooperativeLevel( m_hWnd, DSSCL_PRIORITY ) ) )
		return -1;


	HRESULT             hr;
	LPDIRECTSOUNDBUFFER pDSBPrimary = NULL;

	// �ֻ��� ���۸� �����Ѵ�.

	DWORD dwPrimaryChannels	= 2;		// ���׷���
	DWORD dwPrimaryFreq		= 22050;	// ��û���ļ� 22KHz 
	DWORD dwPrimaryBitRate	= 16;		// ���� ��Ʈ 16
	
	
	// �� ���� ���۸� ��� �´�.
	DSBUFFERDESC dsbd;
	ZeroMemory( &dsbd, sizeof(DSBUFFERDESC) );
	dsbd.dwSize        = sizeof(DSBUFFERDESC);
	dsbd.dwFlags       = DSBCAPS_PRIMARYBUFFER;
	dsbd.dwBufferBytes = 0;
	dsbd.lpwfxFormat   = NULL;
	
	if( FAILED( hr = m_pDS->CreateSoundBuffer( &dsbd, &pDSBPrimary, NULL ) ) )
		return hr;
	
	WAVEFORMATEX wfx;
	ZeroMemory( &wfx, sizeof(WAVEFORMATEX) ); 
	wfx.wFormatTag      = (WORD) WAVE_FORMAT_PCM; 
	wfx.nChannels       = (WORD) dwPrimaryChannels; 
	wfx.nSamplesPerSec  = (DWORD) dwPrimaryFreq; 
	wfx.wBitsPerSample  = (WORD) dwPrimaryBitRate; 
	wfx.nBlockAlign     = (WORD) (wfx.wBitsPerSample / 8 * wfx.nChannels);
	wfx.nAvgBytesPerSec = (DWORD) (wfx.nSamplesPerSec * wfx.nBlockAlign);
	
	// �� ���� ���۸� ����.
	if( FAILED( pDSBPrimary->SetFormat(&wfx) ) )
		return -1;
	
	SAFE_RELEASE( pDSBPrimary );

	return 0;
}

void CMain::Destroy()
{
	// ���� ��ü ����
	SAFE_RELEASE( m_pDS );
}




INT CMain::Restore()
{
	return 0;
}


void CMain::Invalidate()
{
}


INT CMain::FrameMove()
{
	return 0;
}


INT CMain::Render()
{
	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xFF006699, 1.0f, 0 );

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;


	// EndScene
	m_pd3dDevice->EndScene();

	TCHAR	sMsg[128];
	sprintf(sMsg, "Sound Test Press F11 Key         FPS: %4.1f", m_fFps);
	SetWindowText(m_hWnd, sMsg);

	return 0;
}


LRESULT CMain::MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch( msg )
	{
		case WM_PAINT:
		{
			break;
		}
	}
	
	return CApplication::MsgProc( hWnd, msg, wParam, lParam );
}