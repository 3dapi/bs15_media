// Interface for the CMcInput class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCINPUT_H_
#define _MCINPUT_H_

class CMcInput  
{
protected:
	BYTE			m_KeyCur[256]	;											// Current Keyboard
	BYTE			m_KeyOld[256]	;											// Old Keyboard
	
	BYTE			m_KeyMap[256]	;											// Key Map down: 1, up: 2, Press 3
	BYTE			m_BtnMap[8]		;											// Button Map

	POINT			m_pt;

public:
	CMcInput();
	virtual ~CMcInput();

	INT		FrameMove();

	BYTE*	GetKeyMap()	const;
	bool	KeyDown(INT nKey);
	bool	KeyUp(INT nKey);
	bool	KeyPress(INT nKey);
	INT		KeyState(int nKey);

	bool	ButtonDown(INT nBtn);
	bool	ButtonUp(INT nBtn);
	bool	ButtonPress(INT nBtn);
};

#endif