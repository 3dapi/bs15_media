
#include <windows.h>
#include "waveutil.h"

#define SNDLOG(...) { char buf[4096+4]={0}; sprintf(buf, __VA_ARGS__); OutputDebugString(buf); }

struct WAVOBJ
{
	PBYTE           wav_buf ;
	PBYTE           wav_data;
	DWORD           wav_size;
	WAVEFORMATEX*   wav_fmt ;
	HWAVEOUT        wav_hwo ;
	WAVEHDR         wav_hdr ;

	WAVOBJ(PBYTE buf = NULL)
	{
		wav_buf  = buf;
		wav_data = {};
		wav_size = 0;
		wav_fmt  = {};
		wav_hwo  = {};
		wav_hdr  = {};
	}
	~WAVOBJ() { if(wav_buf) { free(wav_buf); wav_buf = NULL; } }
};


// window callback
static void CALLBACK waveOutProc(HWAVEOUT wav_hwo, UINT uMsg, UINT dwInstance, UINT dwParam1, UINT dwParam2)
{
	void* ptr = (void*)dwInstance;
	CWaveObj*	soundObj = (CWaveObj*)ptr;
	if(soundObj)
	{
		soundObj->MsgPrc(uMsg, dwInstance, dwParam1, dwParam2);
		return;
	}

	switch(uMsg)
	{
		case WOM_OPEN:
			SNDLOG("WaveOutProc::WOM_OPEN\n");
			break;
		case WOM_CLOSE:
			SNDLOG("WaveOutProc::WOM_CLOSE\n");
			break;
		case WIM_CLOSE:
			SNDLOG("WaveOutProc::WIM_CLOSE\n");
			break;
		case WIM_DATA :
			SNDLOG("WaveOutProc::WIM_DATA\n");
			break;
		case WOM_DONE:
			SNDLOG("WaveOutProc::WIM_DATA\n");
			break;
	}
}


CWaveObj::~CWaveObj()
{
	Destroy();
}

int CWaveObj::ParseWaveResource()
{
	WAVOBJ* pSoundObj = (WAVOBJ*)m_wav;
	if(!pSoundObj)
		return -1;


	DWORD *pdw=NULL;
	DWORD *pdwEnd=NULL;
	DWORD dwRiff=0;
	DWORD dwType=0;
	DWORD dwLength=0;

	pdw = (DWORD*)pSoundObj->wav_buf;
	dwRiff = *pdw++;
	dwLength = *pdw++;
	dwType = *pdw++;

	if(dwRiff != mmioFOURCC('R', 'I', 'F', 'F'))
		return -1;

	if(dwType != mmioFOURCC('W', 'A', 'V', 'E'))
		return -1;

	pdwEnd = (DWORD*)((BYTE *)pdw + dwLength-4);
	while (pdw < pdwEnd)
	{
		dwType = *pdw++;
		dwLength = *pdw++;

		switch (dwType)
		{
			case mmioFOURCC('f', 'm', 't', ' '):
			{
				if(dwLength < sizeof(WAVEFORMAT))
					return -1;
				pSoundObj->wav_fmt = (WAVEFORMATEX *)pdw;
				if(pSoundObj->wav_data && pSoundObj->wav_size)
					return 0;
				break;
			}
			case mmioFOURCC('d', 'a', 't', 'a'):
			{
				pSoundObj->wav_data = (LPBYTE)pdw;
				pSoundObj->wav_size = dwLength;
				if(pSoundObj->wav_fmt)
					return 0;
				break;
			}
		}

		pdw = (DWORD *)((BYTE *)pdw + ((dwLength+1)&~1));
	}
	return 0;
}

int CWaveObj::Create(const char* sFile)
{
	FILE*	fp = NULL;
	long	fileSize=0;
	PBYTE	pvRes=NULL;
	fp = fopen(sFile, "rb");
	if(!fp)
		return -1;


	fseek(fp, 0, SEEK_END);
	fileSize = ftell(fp);
	fseek(fp, 0, SEEK_SET);

	pvRes = (PBYTE)malloc(fileSize+4);
	fread(pvRes, fileSize, 1, fp);
	fclose(fp);

	WAVOBJ* pSoundObj = new WAVOBJ(pvRes);
	if(!pSoundObj)
	{
		free(pvRes);
		return -1;
	}
	m_wav = pSoundObj;
	if(0>ParseWaveResource())
	{
		free(pvRes);
		delete pSoundObj;
		return -1;
	}


	memset(&pSoundObj->wav_hdr, 0, sizeof(WAVEHDR));
	pSoundObj->wav_hdr.dwBufferLength = pSoundObj->wav_size;
	pSoundObj->wav_hdr.lpData = (LPSTR)pSoundObj->wav_data;
	pSoundObj->wav_hdr.dwFlags |=  (WHDR_BEGINLOOP | WHDR_ENDLOOP);
	pSoundObj->wav_hdr.dwUser = (DWORD_PTR)this;

	MMRESULT hr = waveOutOpen(&pSoundObj->wav_hwo, WAVE_MAPPER, pSoundObj->wav_fmt, (DWORD_PTR) waveOutProc, (DWORD_PTR) this, CALLBACK_FUNCTION | WAVE_ALLOWSYNC);
	if(hr == MMSYSERR_NOERROR)
	{
		hr = this->Prepare();
		if(hr != MMSYSERR_NOERROR)
		{
			SNDLOG("CWaveStream_Create - waveOutPrepareHeader failed: err = %d\n", hr);
			delete(pSoundObj);
			return -1;
		}
	}
	else
	{
		SNDLOG("CWaveStream_Create - waveOutOpen failed: err = %d\n", hr);
		delete(pSoundObj);
		return -1;
	}

	SNDLOG("WaveObject::Create:: success\n");
	m_file = sFile;
	return 0;
}


void CWaveObj::Destroy()
{
	WAVOBJ* pSoundObj = (WAVOBJ*)m_wav;
	if(!pSoundObj)
		return;

	SNDLOG("WaveObject::Destroy\n");
	this->Stop();

	MMRESULT hr = MMSYSERR_NOERROR;
	for(int retries = 0; retries>5; ++retries)
	{
		hr = this->Unprepare();
		if(hr != MMSYSERR_NOERROR)
		{
			SNDLOG("CWaveStream_Close - waveOutUnprepareHeader failed: err = %d\n", hr);
		}

		hr = waveOutClose(pSoundObj->wav_hwo);
		if(hr == MMSYSERR_NOERROR)
		{
			break;
		}
		else
		{
			SNDLOG("CWaveStream_Close - waveOutClose failed: err = %d\n", hr);
		}
		Sleep(10);
	}

	delete (pSoundObj);
}


int CWaveObj::Play()
{
	WAVOBJ* pSoundObj = (WAVOBJ*)m_wav;
	if(!pSoundObj)
		return FALSE;

	this->Stop();

	MMRESULT hr = waveOutWrite(pSoundObj->wav_hwo, &pSoundObj->wav_hdr, sizeof(WAVEHDR));
	if(hr == MMSYSERR_NOERROR)
		return TRUE;

	SNDLOG("CWaveStream_Play - waveOutWrite failed: err = %d\n", hr);
	return FALSE;
}


int CWaveObj::IsPlaying()
{
	WAVOBJ* pSoundObj = (WAVOBJ*)m_wav;
	if(!pSoundObj)
		return FALSE;

	int ret = (pSoundObj->wav_hdr.dwFlags & WHDR_INQUEUE) != 0;
	return ret;
}

int CWaveObj::PlayPanned(long lPan)
{
	WAVOBJ* pSoundObj = (WAVOBJ*)m_wav;
	if(!pSoundObj)
		return FALSE;

	int result = FALSE;
	this->Stop();
	result = this->SetPan(lPan);
	result = this->Play();
	return result;
}

int CWaveObj::Stop()
{
	WAVOBJ* pSoundObj = (WAVOBJ*)m_wav;
	if(!pSoundObj)
		return FALSE;

	SNDLOG("WaveObject::Stop()\n");
	if(!msg_proc)
	{
		MMRESULT hr = waveOutReset(pSoundObj->wav_hwo);
		if(hr == MMSYSERR_NOERROR)
			return TRUE;
		else
			SNDLOG("CWaveStream_Stop: waveOutReset failed: err =%d\n", hr);
	}
	return FALSE;
}

int CWaveObj::SetPan(double dPan)
{
	WAVOBJ* pSoundObj = (WAVOBJ*)m_wav;
	if(!pSoundObj)
		return FALSE;

	if(dPan < -1.0)
		dPan = -1.0;
	else if(dPan > +1.0)
		dPan = +1.0;

	MMRESULT hr;
	DWORD dwVolume;
	if(dPan < 0)
	{
		// -10000 -> set right volume to max, left volume per pan
		DWORD dwLeft = ((10000 - ((DWORD) (-dPan))) * 0xffff) / 10000;
		dwVolume = dwLeft | 0xffff0000;
	}
	else if(dPan > 0)
	{
		// +10000 -> set left volume to max, right volume per pan
		DWORD dwRight = ((10000 - ((DWORD) ( dPan))) * 0xffff) / 10000;
		dwVolume = (dwRight << 16) | 0xffff;
	}
	else
	{
		dwVolume = 0xFFFFFFFF;
	}

	hr = waveOutSetVolume(pSoundObj->wav_hwo, dwVolume);
	if(hr == MMSYSERR_NOERROR)
		return TRUE;

	SNDLOG("CWaveStream_SetPan: waveOutSetVolume failed: err =%d\n", hr);
	return FALSE;
}

int CWaveObj::SetSpeed(double dRate)
{
	WAVOBJ* pSoundObj = (WAVOBJ*)m_wav;
	if(!pSoundObj)
		return FALSE;

	int result = FALSE;
	ULONG ulRate = (ULONG) (0x10000 * dRate);

	MMRESULT hr = waveOutSetPlaybackRate(pSoundObj->wav_hwo, ulRate);
	if(hr == MMSYSERR_NOERROR)
		return TRUE;
	SNDLOG("CWaveStream_SetRate: waveOutSetPlaybackRate failed: err =%d\n", hr);
	return result;
}

int CWaveObj::SetVolume(double dVolume)
{
	WAVOBJ* pSoundObj = (WAVOBJ*)m_wav;
	if(!pSoundObj)
		return FALSE;

	if(0>dVolume)
		dVolume = 0;
	else if(1.0<dVolume)
		dVolume = 1.0;

	DWORD ulVolume = (DWORD)(dVolume * 0xFFFF);
	MMRESULT hr = waveOutSetVolume(pSoundObj->wav_hwo, ulVolume);
	if(hr == MMSYSERR_NOERROR)
		return TRUE;

	SNDLOG("CWaveStream_SetRate: waveOutSetVolume failed: err =%d\n", hr);
	return FALSE;
}

double CWaveObj::GetVolume()
{
	WAVOBJ* pSoundObj = (WAVOBJ*)m_wav;
	if(!pSoundObj)
		return 0.0f;

	double ret = 0.0;
	DWORD  ulVolume=0;
	MMRESULT hr = waveOutGetVolume(pSoundObj->wav_hwo, &ulVolume);
	if(hr == MMSYSERR_NOERROR)
	{
		ret = double(ulVolume)/0xFFFF;
		return ret;
	}
	SNDLOG("CWaveStream_GetVolume: waveOutGetVolume failed: err =%d\n", hr);
	return 0.0;
}

unsigned int CWaveObj::GetDuration()
{
	WAVOBJ* pSoundObj = (WAVOBJ*)m_wav;
	if(!pSoundObj)
		return 0;
	SNDLOG("WaveObject::GetDuration()\n");
	unsigned int ret = (1000 * pSoundObj->wav_size) / pSoundObj->wav_fmt->nAvgBytesPerSec;
	return ret;
}

int CWaveObj::Prepare()
{
	WAVOBJ* pSoundObj = (WAVOBJ*)m_wav;
	if(!pSoundObj)
		return 0;
	int ret = (int)waveOutPrepareHeader(pSoundObj->wav_hwo, &pSoundObj->wav_hdr, sizeof(WAVEHDR));
	return ret;
}

int CWaveObj::Unprepare()
{
	WAVOBJ* pSoundObj = (WAVOBJ*)m_wav;
	if(!pSoundObj)
		return 0;
	int ret = (int)waveOutUnprepareHeader(pSoundObj->wav_hwo, &pSoundObj->wav_hdr, sizeof(WAVEHDR));
	return ret;
}

void CWaveObj::MsgPrc(unsigned int uMsg, long long dwInstance, long long dwParam1, long long dwParam2)
{
	switch(uMsg)
	{
		case WOM_OPEN:
			SNDLOG("MsgPrc::WOM_OPEN\n");
			break;
		case WOM_CLOSE:
			SNDLOG("MsgPrc::WOM_CLOSE\n");
			break;
		case WIM_CLOSE:
			SNDLOG("MsgPrc::WIM_CLOSE\n");
			break;
		case WIM_DATA :
			SNDLOG("MsgPrc::WIM_DATA\n");
			break;
		case WOM_DONE:
		{
			SNDLOG("MsgPrc::WOM_DONE\n");
			this->msg_proc =true;
			MMRESULT hr = this->Prepare();
			if(hr != MMSYSERR_NOERROR)
			{
				SNDLOG("CWaveStream_Create - waveOutPrepareHeader failed: err = %d\n", hr);
				this->msg_proc = false;
				break;
			}
			this->Play();
			this->msg_proc =false;
			break;
		}
	}
}


// create Instance
CWaveObj* Wav_Create(const char* file_name)
{
	CWaveObj* pSoundObj = new CWaveObj;
	if(FAILED(pSoundObj->Create(file_name)))
	{
		delete pSoundObj;
		return NULL;
	}
	return pSoundObj;
}



