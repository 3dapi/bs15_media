
#ifndef _waveutil_H_
#define _waveutil_H_

#pragma warning(disable: 4996)

#include <string>

class CWaveObj
{
public:
	CWaveObj() : m_wav(NULL), msg_proc(false){}
	virtual ~CWaveObj();

	int          Create(const char* lpName);
	void         Destroy();
	int          Play();
	int          IsPlaying();
	int          SetSpeed(double dRate);
	int          SetVolume(double dVolume);
	double       GetVolume();
	int          SetPan(double dPan);
	int          PlayPanned(long lPan);
	int          Stop();
	unsigned int GetDuration();
	void         MsgPrc(unsigned int uMsg, long long dwInstance, long long dwParam1, long long dwParam2);
protected:
	void*        m_wav;
	std::string  m_file;
	bool         msg_proc;

	int          Prepare();
	int          Unprepare();
	int          ParseWaveResource();
};
CWaveObj* Wav_Create(const char* file_name);

#endif
