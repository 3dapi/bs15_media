// Implementation of the CMcInput class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcInput::CMcInput()
{
	memset(  m_KeyCur, 0, sizeof  m_KeyCur);
	memset(  m_KeyOld, 0, sizeof  m_KeyOld);

	memset(  m_KeyMap, 0, sizeof  m_KeyMap);
	memset(  m_BtnMap, 0, sizeof  m_BtnMap);
}

CMcInput::~CMcInput()
{
	
}


INT CMcInput::FrameMove()
{
	int i;
	HWND	hWnd = GetActiveWindow();

	memcpy(m_KeyOld, m_KeyCur, sizeof m_KeyOld);

	memset(m_KeyCur,		0, sizeof m_KeyCur);
	memset(m_KeyMap,		0, sizeof m_KeyMap);
	memset(m_BtnMap,		0, sizeof m_BtnMap);

	GetKeyboardState(m_KeyCur);

	for(i=0; i<256; ++i)
	{
		m_KeyCur[i] = (m_KeyCur[i] & 0x80)? 1: 0;

		INT nOld = m_KeyOld[i];
		INT nCur = m_KeyCur[i];

		if		(0 == nOld && 1 ==nCur)	m_KeyMap[i] = 1;		// Down
		else if	(1 == nOld && 0 ==nCur)	m_KeyMap[i] = 2;		// Up
		else if	(1 == nOld && 1 ==nCur)	m_KeyMap[i] = 3;		// Press
	}

	m_BtnMap[0] = m_KeyMap[VK_LBUTTON];
	m_BtnMap[1] = m_KeyMap[VK_RBUTTON];
	m_BtnMap[2] = m_KeyMap[VK_MBUTTON];


	::GetCursorPos(&m_pt);
	::ScreenToClient( hWnd, &m_pt);
	
	return 1;
}


BYTE* CMcInput::GetKeyMap() const
{
	return (BYTE*)m_KeyMap;
}



bool CMcInput::KeyDown(INT nKey)
{
	return (1 == m_KeyMap[nKey])? 1: 0;
}

bool CMcInput::KeyUp(INT nKey)
{
	return (2 == m_KeyMap[nKey])? 1: 0;
}

bool CMcInput::KeyPress(INT nKey)
{
	return (3 == m_KeyMap[nKey])? 1: 0;
}

INT CMcInput::KeyState(int nKey)
{
	return m_KeyMap[nKey];
}






bool CMcInput::ButtonDown(INT nBtn)
{
	return (1 == m_BtnMap[nBtn])? 1: 0;
}

bool CMcInput::ButtonUp(INT nBtn)
{
	return (2 == m_BtnMap[nBtn])? 1: 0;
}

bool CMcInput::ButtonPress(INT nBtn)
{
	return (3 == m_BtnMap[nBtn])? 1: 0;
}
