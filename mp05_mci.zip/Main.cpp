// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <mmsystem.h>
#include <digitalv.h>

#include "_StdAfx.h"


int MciGetError (DWORD hr)
{
	if(0==hr)
		return 0;

	TCHAR szErrorStr [1024] ;
	mciGetErrorString (hr, szErrorStr, sizeof (szErrorStr) / sizeof (TCHAR)) ;
	MessageBox (NULL, szErrorStr, "Err", MB_OK);

	return -1;
}


CMain::CMain()
{
	m_pInput	= NULL;
}


INT CMain::Init()
{
	m_pInput = new CMcInput;

	
	MCI_OPEN_PARMS		mciOpen ;
	MCI_PLAY_PARMS		mciPlay ;
//	MCI_GENERIC_PARMS	mciStop	;
//	MCI_GENERIC_PARMS	mciClose;
	
	// Media ������ ����.
	mciOpen.dwCallback       = 0 ;
	mciOpen.wDeviceID        = 0 ;
	mciOpen.lpstrDeviceType  = NULL ;
	mciOpen.lpstrElementName = "Sound/s1.wav";
	mciOpen.lpstrAlias       = NULL ;  
	
	MCIERROR hr = mciSendCommand (0, MCI_OPEN,MCI_WAIT | MCI_OPEN_ELEMENT,(DWORD) (LPMCI_OPEN_PARMS) &mciOpen);
	
	if(FAILED(MciGetError(hr)))
		return -1;
	
	// �̵� ����Ѵ�.
	mciPlay.dwCallback = (DWORD) m_hWnd ;
	mciPlay.dwFrom     = 0 ;
	mciPlay.dwTo       = 0 ;

	// ���忡�� MCI_DGV_PLAY_REPEAT �÷��� ���� ������ �ȵȴ�.
	// Window Callback�Լ����� MM_MCINOTIFY �̺�Ʈ���� ó����ġ��
	// �̵� �̵��� ���� �ٽ� ����ؾ� �Ѵ�.

	DWORD	dFlags = MCI_NOTIFY | MCI_DGV_PLAY_REPEAT;
	hr = mciSendCommand (mciOpen.wDeviceID, MCI_PLAY, dFlags,(DWORD) (LPMCI_PLAY_PARMS) &mciPlay) ;

	if(FAILED(MciGetError(hr)))
		return -1;


	// Close
	// mciSendCommand (mciOpen.wDeviceID, MCI_CLOSE, 0, NULL) ;

	return 0;
}

void CMain::Destroy()
{
	SAFE_DELETE(	m_pInput	);

	// Generic Stop and close
	MCIDEVICEID wDeviceID=0;
	MCI_GENERIC_PARMS mciGeneric ;
	mciGeneric.dwCallback = 0 ;
	
	mciSendCommand (MCI_ALL_DEVICE_ID, MCI_STOP, 0, NULL) ;
	mciSendCommand (MCI_ALL_DEVICE_ID, MCI_CLOSE, MCI_WAIT, NULL) ;
}




INT CMain::Restore()
{
	return 0;
}


void CMain::Invalidate()
{
}


INT CMain::FrameMove()
{
	if(m_pInput)
		m_pInput->FrameMove();

	return 0;
}


INT CMain::Render()
{
	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xFF006699, 1.0f, 0 );

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;


	// EndScene
	m_pd3dDevice->EndScene();

	TCHAR	sMsg[128];
	sprintf(sMsg, "Media Test.");
	SetWindowText(m_hWnd, sMsg);

	return 0;
}


LRESULT CMain::MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch(msg)
	{
		case MM_MCINOTIFY :
		{
			MCI_SEEK_PARMS	mciSeek;
			MCIERROR		hr;

			WPARAM			wFlags = wParam;
			MCIDEVICEID		mciId = (LONG)lParam;

			mciSeek.dwCallback = 0;
			mciSeek.dwTo       = 0;

			// �̵� �ʱ� ��ġ�� �̵��Ѵ�.
			hr = mciSendCommand(mciId, MCI_SEEK, MCI_SEEK_TO_START, (DWORD)&mciSeek);

			MciGetError(hr);

			MCI_PLAY_PARMS    mciPlay ;

			mciPlay.dwCallback = (DWORD) hWnd ;
			mciPlay.dwFrom     = 0 ;
			mciPlay.dwTo       = 0 ;

			// �̵� ����Ѵ�.
			DWORD	dFlags = MCI_NOTIFY| MCI_DGV_PLAY_REPEAT;
			hr = mciSendCommand (mciId, MCI_PLAY, dFlags,(DWORD) (LPMCI_PLAY_PARMS) &mciPlay) ;

			return 0;
		}

		case WM_PAINT:
		{
			break;
		}
	}
	
	return CApplication::MsgProc( hWnd, msg, wParam, lParam );
}